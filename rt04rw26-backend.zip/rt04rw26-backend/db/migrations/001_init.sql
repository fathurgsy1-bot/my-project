-- =============================================================================
-- Dashboard RT04/RW26 - skema awal (PostgreSQL 13+)
-- Menggantikan Google Sheets: ADMIN, WARGA, ANGSURAN, TUNGGAKAN, KAS, UNDANGAN,
-- KEGIATAN, NOTULEN, INVENTARIS, SURAT, REKAPKK.
-- Dijalankan otomatis oleh server (AUTO_MIGRATE=true) atau manual:
--   psql "$DATABASE_URL" -v ON_ERROR_STOP=1 --single-transaction -f db/migrations/001_init.sql
-- =============================================================================

-- Trigger umum untuk kolom updated_at
CREATE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ---------------------------------------------------------------- users (ADMIN)
CREATE TABLE users (
  id             BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  username       TEXT        NOT NULL CHECK (char_length(btrim(username)) BETWEEN 3 AND 50),
  password_hash  TEXT        NOT NULL,
  role           TEXT        NOT NULL DEFAULT 'warga'
                 CHECK (role IN ('admin', 'bendahara', 'sekretaris', 'warga')),
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX users_username_uq ON users (lower(btrim(username)));
CREATE TRIGGER users_updated_at BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------------------------------------------------------------------- warga
CREATE TABLE warga (
  id                 BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  nama               TEXT        NOT NULL CHECK (btrim(nama) <> ''),
  nomor_kk           TEXT,
  nik                TEXT,
  alamat             TEXT,
  hubungan_keluarga  TEXT,
  jenis_kelamin      TEXT,
  tempat_lahir       TEXT,
  tanggal_lahir      DATE,
  agama              TEXT,
  pekerjaan          TEXT,
  gol_darah          TEXT,
  status_kawin       TEXT,
  tanggal_kawin      DATE,
  access_token       TEXT,          -- token acak di dalam QR (jalur publik cek tunggakan)
  qr_url             TEXT,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- Nama dipakai sebagai kunci bisnis di Sheets (pembayaran & tunggakan), jadi dibuat unik.
CREATE UNIQUE INDEX warga_nama_uq         ON warga (lower(btrim(nama)));
CREATE UNIQUE INDEX warga_nik_uq          ON warga (nik) WHERE nik IS NOT NULL AND nik <> '';
CREATE UNIQUE INDEX warga_access_token_uq ON warga (access_token) WHERE access_token IS NOT NULL;
CREATE INDEX        warga_nomor_kk_idx    ON warga (nomor_kk);
CREATE TRIGGER warga_updated_at BEFORE UPDATE ON warga
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ------------------------------------------------- tunggakan_lama (sheet TUNGGAKAN)
CREATE TABLE tunggakan_lama (
  warga_id    BIGINT      PRIMARY KEY REFERENCES warga(id) ON DELETE CASCADE,
  nominal     BIGINT      NOT NULL DEFAULT 0 CHECK (nominal >= 0),
  catatan     TEXT        NOT NULL DEFAULT '',
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TRIGGER tunggakan_lama_updated_at BEFORE UPDATE ON tunggakan_lama
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ------------------------------ angsuran (sheet ANGSURAN, pivot -> 1 baris/bulan)
CREATE TABLE angsuran (
  id          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  warga_id    BIGINT      NOT NULL REFERENCES warga(id) ON DELETE CASCADE,
  tahun       SMALLINT    NOT NULL CHECK (tahun BETWEEN 2000 AND 2100),
  bulan       SMALLINT    NOT NULL CHECK (bulan BETWEEN 1 AND 12),
  bayar       BIGINT      NOT NULL DEFAULT 0 CHECK (bayar >= 0),
  catatan     TEXT        NOT NULL DEFAULT '',   -- pengganti "cell note" Sheets
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT angsuran_warga_periode_uq UNIQUE (warga_id, tahun, bulan)
);
CREATE INDEX angsuran_tahun_idx ON angsuran (tahun, bulan);
CREATE TRIGGER angsuran_updated_at BEFORE UPDATE ON angsuran
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ------------------------------------------------------------------ kas (KAS)
CREATE TABLE kas (
  id          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  tanggal     TIMESTAMPTZ NOT NULL DEFAULT now(),
  keterangan  TEXT        NOT NULL CHECK (btrim(keterangan) <> ''),
  bulan       SMALLINT    NOT NULL CHECK (bulan BETWEEN 1 AND 12),
  tahun       SMALLINT    NOT NULL CHECK (tahun BETWEEN 2000 AND 2100),
  debet       BIGINT      NOT NULL DEFAULT 0 CHECK (debet >= 0),    -- pemasukan
  kredit      BIGINT      NOT NULL DEFAULT 0 CHECK (kredit >= 0),   -- pengeluaran
  warga_id    BIGINT      REFERENCES warga(id) ON DELETE SET NULL, -- diisi bila dari iuran warga
  created_by  BIGINT      REFERENCES users(id) ON DELETE SET NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX kas_tanggal_idx ON kas (tanggal, id);
CREATE INDEX kas_periode_idx ON kas (tahun, bulan);
CREATE TRIGGER kas_updated_at BEFORE UPDATE ON kas
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Saldo berjalan dihitung otomatis (di Sheets harus recalculateKasSaldo manual).
CREATE VIEW v_kas_saldo AS
SELECT k.*,
       ROW_NUMBER() OVER w                      AS no,
       (SUM(k.debet - k.kredit) OVER w)::BIGINT AS saldo
FROM kas k
WINDOW w AS (ORDER BY k.tanggal, k.id);

-- ------------------------------------------------------------ pertemuan (UNDANGAN)
CREATE TABLE pertemuan (
  id          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  tanggal     DATE        NOT NULL,
  judul       TEXT        NOT NULL DEFAULT '',
  lokasi      TEXT        NOT NULL DEFAULT '',
  keterangan  TEXT        NOT NULL DEFAULT '',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX pertemuan_tanggal_idx ON pertemuan (tanggal);
CREATE TRIGGER pertemuan_updated_at BEFORE UPDATE ON pertemuan
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -------------------------------------------------------------------- kegiatan
CREATE TABLE kegiatan (
  id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  tanggal         DATE,
  nama_kegiatan   TEXT        NOT NULL CHECK (btrim(nama_kegiatan) <> ''),
  deskripsi       TEXT        NOT NULL DEFAULT '',
  foto_url        TEXT        NOT NULL DEFAULT '',
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TRIGGER kegiatan_updated_at BEFORE UPDATE ON kegiatan
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- --------------------------------------------------------------------- notulen
CREATE TABLE notulen (
  id            BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  tanggal       DATE,
  judul         TEXT        NOT NULL CHECK (btrim(judul) <> ''),
  isi           TEXT        NOT NULL DEFAULT '',
  pertemuan_id  BIGINT      REFERENCES pertemuan(id) ON DELETE SET NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TRIGGER notulen_updated_at BEFORE UPDATE ON notulen
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ------------------------------------------------------------------ inventaris
CREATE SEQUENCE inventaris_kode_seq START 1;
CREATE TABLE inventaris (
  id           BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  kode_barang  TEXT        NOT NULL UNIQUE
               DEFAULT ('INV-' || lpad(nextval('inventaris_kode_seq')::text, 4, '0')),
  nama_barang  TEXT        NOT NULL CHECK (btrim(nama_barang) <> ''),
  kategori     TEXT        NOT NULL DEFAULT '',
  kondisi      TEXT        NOT NULL DEFAULT '',
  lokasi       TEXT        NOT NULL DEFAULT '',   -- lokasi / pemegang
  jumlah       INTEGER     NOT NULL DEFAULT 0 CHECK (jumlah >= 0),
  keterangan   TEXT        NOT NULL DEFAULT '',
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TRIGGER inventaris_updated_at BEFORE UPDATE ON inventaris
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- --------------------------------------------------------------- surat_pengantar
CREATE TABLE surat_pengantar (
  id           BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  tanggal      TIMESTAMPTZ NOT NULL DEFAULT now(),
  nomor_surat  TEXT        NOT NULL DEFAULT '',
  warga_id     BIGINT      REFERENCES warga(id) ON DELETE SET NULL,
  nama         TEXT        NOT NULL CHECK (btrim(nama) <> ''),
  nik          TEXT        NOT NULL DEFAULT '',
  alamat       TEXT        NOT NULL DEFAULT '',
  keperluan    TEXT        NOT NULL DEFAULT '',
  status_surat TEXT        NOT NULL DEFAULT 'Terbit',
  file_url     TEXT        NOT NULL DEFAULT '',
  created_by   BIGINT      REFERENCES users(id) ON DELETE SET NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX surat_pengantar_tanggal_idx ON surat_pengantar (tanggal DESC);

-- ----------------------------------------------------------- rekap KK (REKAPKK)
CREATE VIEW v_rekap_kk AS
SELECT nomor_kk,
       COUNT(*)                                                       AS jumlah_anggota,
       MAX(nama)  FILTER (WHERE lower(hubungan_keluarga) LIKE 'kepala%') AS kepala_keluarga,
       MAX(alamat)                                                    AS alamat
FROM warga
WHERE nomor_kk IS NOT NULL AND nomor_kk <> ''
GROUP BY nomor_kk;
