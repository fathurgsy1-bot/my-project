// Command server menjalankan backend Dashboard RT04/RW26.
package main

import (
	"context"
	"database/sql"
	"errors"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	_ "github.com/lib/pq"
	_ "time/tzdata" // zona waktu ikut di binary (image minimal tanpa tzdata tetap jalan)

	"github.com/rt04rw26/backend/db"
	"github.com/rt04rw26/backend/internal/api"
	"github.com/rt04rw26/backend/internal/config"
)

func main() {
	log := slog.New(slog.NewJSONHandler(os.Stdout, nil))
	if err := run(log); err != nil {
		log.Error("server berhenti", "err", err)
		os.Exit(1)
	}
}

func run(log *slog.Logger) error {
	cfg, err := config.Load()
	if err != nil {
		return err
	}
	conn, err := sql.Open("postgres", cfg.DatabaseURL)
	if err != nil {
		return err
	}
	defer conn.Close()
	conn.SetMaxOpenConns(20)
	conn.SetMaxIdleConns(5)
	conn.SetConnMaxLifetime(30 * time.Minute)

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	// Tunggu DB siap (berguna saat docker compose menyalakan app & postgres bersamaan).
	for i := 0; ; i++ {
		pctx, cancel := context.WithTimeout(ctx, 3*time.Second)
		err = conn.PingContext(pctx)
		cancel()
		if err == nil {
			break
		}
		if i >= 20 {
			return errors.New("database tidak dapat dihubungi: " + err.Error())
		}
		log.Warn("menunggu database...", "err", err)
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-time.After(2 * time.Second):
		}
	}

	if cfg.AutoMigrate {
		applied, err := db.Migrate(ctx, conn)
		if err != nil {
			return err
		}
		log.Info("migrasi selesai", "diterapkan", applied)
	}

	srv, err := api.New(conn, cfg, log)
	if err != nil {
		return err
	}
	if err := srv.EnsureAdmin(ctx); err != nil {
		return err
	}

	httpSrv := &http.Server{
		Addr:              ":" + cfg.Port,
		Handler:           srv.Handler(),
		ReadHeaderTimeout: 10 * time.Second,
		ReadTimeout:       30 * time.Second,
		WriteTimeout:      60 * time.Second,
		IdleTimeout:       120 * time.Second,
	}
	errCh := make(chan error, 1)
	go func() {
		log.Info("server berjalan", "addr", httpSrv.Addr)
		errCh <- httpSrv.ListenAndServe()
	}()
	select {
	case err := <-errCh:
		return err
	case <-ctx.Done():
		log.Info("mematikan server...")
		sctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
		defer cancel()
		return httpSrv.Shutdown(sctx)
	}
}
