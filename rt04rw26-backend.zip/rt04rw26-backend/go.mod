module github.com/rt04rw26/backend

go 1.22.2

require (
	github.com/lib/pq v1.10.9
	github.com/skip2/go-qrcode v0.0.0-20200617195104-da1b6568686e
)
