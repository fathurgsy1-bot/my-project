// Package web menyimpan template HTML yang dibawa di dalam binary.
package web

import _ "embed"

//go:embed cek.html
var CekHTML string
