# Backend Dashboard RT04/RW26 (Go + PostgreSQL)

Hasil migrasi dari Google Apps Script. Satu binary, tanpa dependensi runtime selain PostgreSQL 13+.

## Deploy cepat (Docker)
```bash
cp .env.example .env        # isi DB_PASSWORD, JWT_SECRET, PUBLIC_BASE_URL, ADMIN_PASSWORD
docker compose up -d --build
curl localhost:8080/healthz
```
Tabel dibuat otomatis saat start (`AUTO_MIGRATE=true`). Manual: `make migrate` atau
`psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -1 -f db/migrations/001_init.sql`.

## Deploy tanpa Docker
`make build` -> salin `bin/server` + `.env` ke server -> pakai `deploy/rt04rw26.service` (systemd) dan `deploy/Caddyfile` (HTTPS).

## Autentikasi
`POST /api/auth/login {username,password}` -> `token`. Kirim `Authorization: Bearer <token>`.
Frontend perlu menyimpan token (halaman `/cek/{token}` membaca `localStorage.warganetSession = {token, role}`).
Role: admin (semua), bendahara (kas, tunggakan, bayar), sekretaris (warga, QR, inventaris, surat, kegiatan, notulen, pertemuan), warga (tidak punya akses data).

## Endpoint
| Area | Endpoint |
|---|---|
| Publik | `GET /healthz`, `POST /api/auth/register`, `POST /api/auth/login`, `GET /cek/{token}`, `GET /api/public/tunggakan/{token}`, `GET /files/...` |
| Umum | `GET /api/auth/me`, `GET /api/menu` |
| Dashboard | `GET /api/dashboard/summary`, `/charts?tahun=`, `/clients` |
| Tunggakan | `GET /api/tunggakan`, `/api/tunggakan/warga`, `/api/tunggakan/warga/{id}`, `GET/PUT /api/tunggakan-lama[/{wargaId}]`, `GET /api/angsuran/{wargaId}`, `PUT /api/angsuran/{wargaId}/{tahun}/{bulan}` |
| Kas | `GET/POST /api/kas`, `PUT/DELETE /api/kas/{id}`, `POST /api/kas/bayar` |
| Warga | `GET/POST /api/warga`, `POST /api/warga/bulk`, `PUT/DELETE /api/warga/{id}`, `GET /api/warga/kartu`, `POST /api/warga/{id}/qr`, `POST /api/warga/qr/bulk`, `GET /api/rekap-kk` |
| Lainnya | `/api/inventaris`, `/api/surat`, `/api/kegiatan`, `/api/notulen`, `/api/pertemuan` (CRUD), `POST /api/upload`, `/api/users` (admin) |

Respons sukses mutasi: `{"success":true,"message":...}`; gagal: `{"success":false,"error":...}` dengan status HTTP yang sesuai.

## Perilaku yang dipertahankan dari Apps Script
- Biaya Rp35.000/bulan (`FEE_PER_MONTH`); tunggakan = tunggakan lama + kekurangan bulan di tahun berjalan.
- Bulan berjalan baru dihitung bila ada pertemuan (tabel `pertemuan`) bulan ini dengan tanggal <= hari ini.
- Setoran melunasi tunggakan lama dulu, lalu mengisi bulan yang kurang dari Januari (mulai tahun terkecil di `angsuran`; ubah dengan `PAYMENT_START_YEAR`).

## Yang berubah
- Password PBKDF2 (hash SHA-256 lama diupgrade saat login). Token QR tidak berubah bila sudah ada.
- QR dibuat lokal (PNG di `STORAGE_DIR/qr`), bukan Google Drive. Backup `STORAGE_DIR` dan database.
- Nama warga harus unik (dipakai sebagai kunci seperti di Sheets).
- Pembayaran atas warga yang tidak ada ditolak (404).

## Impor data lama
Ekspor tiap sheet ke CSV lalu impor ke tabel terkait (WARGA -> `warga`; TUNGGAKAN -> `tunggakan_lama`; ANGSURAN pivot -> `angsuran`: 1 baris per warga/tahun/bulan; ADMIN -> `users`, hash SHA-256 lama masih diterima).
