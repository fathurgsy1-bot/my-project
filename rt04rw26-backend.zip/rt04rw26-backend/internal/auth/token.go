package auth

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"strings"
	"time"
)

type Claims struct {
	Sub  int64  `json:"sub"`
	Usr  string `json:"usr"`
	Role string `json:"role"`
	Iat  int64  `json:"iat"`
	Exp  int64  `json:"exp"`
}

type Manager struct {
	secret []byte
	ttl    time.Duration
}

func NewManager(secret string, ttl time.Duration) *Manager {
	return &Manager{secret: []byte(secret), ttl: ttl}
}

var (
	b64         = base64.RawURLEncoding
	headerPart  = b64.EncodeToString([]byte(`{"alg":"HS256","typ":"JWT"}`))
	ErrBadToken = errors.New("token tidak valid")
	ErrExpired  = errors.New("sesi berakhir, silakan login lagi")
)

func (m *Manager) Issue(userID int64, username, role string) (string, time.Time, error) {
	now := time.Now()
	exp := now.Add(m.ttl)
	payload, err := json.Marshal(Claims{Sub: userID, Usr: username, Role: role, Iat: now.Unix(), Exp: exp.Unix()})
	if err != nil {
		return "", time.Time{}, err
	}
	signing := headerPart + "." + b64.EncodeToString(payload)
	return signing + "." + m.sign(signing), exp, nil
}

func (m *Manager) Parse(token string) (*Claims, error) {
	parts := strings.Split(token, ".")
	if len(parts) != 3 || parts[0] != headerPart { // tolak alg lain (mis. "none")
		return nil, ErrBadToken
	}
	if !hmac.Equal([]byte(m.sign(parts[0]+"."+parts[1])), []byte(parts[2])) {
		return nil, ErrBadToken
	}
	raw, err := b64.DecodeString(parts[1])
	if err != nil {
		return nil, ErrBadToken
	}
	var c Claims
	if err := json.Unmarshal(raw, &c); err != nil {
		return nil, ErrBadToken
	}
	if time.Now().Unix() >= c.Exp {
		return nil, ErrExpired
	}
	return &c, nil
}

func (m *Manager) sign(s string) string {
	h := hmac.New(sha256.New, m.secret)
	h.Write([]byte(s))
	return b64.EncodeToString(h.Sum(nil))
}
