// Package auth: hashing password dan token sesi (JWT HS256), hanya stdlib.
package auth

import (
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/base64"
	"encoding/binary"
	"encoding/hex"
	"errors"
	"fmt"
	"hash"
	"regexp"
	"strconv"
	"strings"
)

const (
	pbkdf2Iter = 210_000 // rekomendasi OWASP untuk PBKDF2-HMAC-SHA256
	saltLen    = 16
	keyLen     = 32
)

var legacySHA256 = regexp.MustCompile(`^[a-f0-9]{64}$`)

// HashPassword menghasilkan "pbkdf2_sha256$iter$salt$hash".
func HashPassword(password string) (string, error) {
	salt := make([]byte, saltLen)
	if _, err := rand.Read(salt); err != nil {
		return "", err
	}
	dk := pbkdf2(sha256.New, []byte(password), salt, pbkdf2Iter, keyLen)
	return fmt.Sprintf("pbkdf2_sha256$%d$%s$%s", pbkdf2Iter,
		base64.RawStdEncoding.EncodeToString(salt), base64.RawStdEncoding.EncodeToString(dk)), nil
}

// CheckPassword memverifikasi password. needsRehash=true bila hash masih format
// lama (SHA-256 hex dari Apps Script `hashPassword`) atau iterasinya sudah usang.
func CheckPassword(password, stored string) (ok, needsRehash bool) {
	if legacySHA256.MatchString(stored) {
		sum := sha256.Sum256([]byte(password))
		return subtle.ConstantTimeCompare([]byte(hex.EncodeToString(sum[:])), []byte(stored)) == 1, true
	}
	parts := strings.Split(stored, "$")
	if len(parts) != 4 || parts[0] != "pbkdf2_sha256" {
		return false, false
	}
	iter, err := strconv.Atoi(parts[1])
	if err != nil || iter <= 0 {
		return false, false
	}
	salt, err1 := base64.RawStdEncoding.DecodeString(parts[2])
	want, err2 := base64.RawStdEncoding.DecodeString(parts[3])
	if err1 != nil || err2 != nil || len(want) == 0 {
		return false, false
	}
	got := pbkdf2(sha256.New, []byte(password), salt, iter, len(want))
	return subtle.ConstantTimeCompare(got, want) == 1, iter < pbkdf2Iter
}

// DummyCheck menyamakan waktu respons saat username tidak ditemukan.
func DummyCheck(password string) {
	pbkdf2(sha256.New, []byte(password), make([]byte, saltLen), pbkdf2Iter, keyLen)
}

func ValidatePassword(p string) error {
	if len(p) < 8 {
		return errors.New("password minimal 8 karakter")
	}
	if len(p) > 128 {
		return errors.New("password maksimal 128 karakter")
	}
	return nil
}

// pbkdf2 (RFC 8018) hanya dengan stdlib, agar tanpa dependensi eksternal.
func pbkdf2(h func() hash.Hash, password, salt []byte, iter, keyLen int) []byte {
	prf := hmac.New(h, password)
	hLen := prf.Size()
	blocks := (keyLen + hLen - 1) / hLen
	var out []byte
	buf := make([]byte, 4)
	for b := 1; b <= blocks; b++ {
		prf.Reset()
		prf.Write(salt)
		binary.BigEndian.PutUint32(buf, uint32(b))
		prf.Write(buf)
		u := prf.Sum(nil)
		t := append([]byte(nil), u...)
		for i := 1; i < iter; i++ {
			prf.Reset()
			prf.Write(u)
			u = prf.Sum(u[:0])
			for j := range t {
				t[j] ^= u[j]
			}
		}
		out = append(out, t...)
	}
	return out[:keyLen]
}
