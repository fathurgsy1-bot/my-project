package api

import (
	"database/sql"
	"net/http"
	"strconv"
	"strings"
)

// Nama field JSON mengikuti payload lama (p.nomorKK, p.golDarah, p.tglKawin, ...).
type wargaReq struct {
	Nama         string `json:"nama"`
	NomorKK      string `json:"nomorKK"`
	NIK          string `json:"nik"`
	Alamat       string `json:"alamat"`
	HubunganKK   string `json:"hubunganKK"`
	JenisKelamin string `json:"jenisKelamin"`
	TempatLahir  string `json:"tempatLahir"`
	TanggalLahir string `json:"tanggalLahir"`
	Agama        string `json:"agama"`
	Pekerjaan    string `json:"pekerjaan"`
	GolDarah     string `json:"golDarah"`
	StatusKawin  string `json:"statusKawin"`
	TglKawin     string `json:"tglKawin"`
}

type wargaArgs struct {
	args []any
}

func (p *wargaReq) prepare() (*wargaArgs, string) {
	p.Nama = strings.TrimSpace(p.Nama)
	if p.Nama == "" {
		return nil, "nama wajib diisi"
	}
	if p.NIK = strings.TrimSpace(p.NIK); p.NIK != "" && !isDigits(p.NIK, 16) {
		return nil, "NIK harus 16 digit angka"
	}
	lahir, err := parseDate(p.TanggalLahir)
	if err != nil {
		return nil, "tanggalLahir: " + err.Error()
	}
	kawin, err := parseDate(p.TglKawin)
	if err != nil {
		return nil, "tglKawin: " + err.Error()
	}
	var lahirV, kawinV any
	if lahir.Valid {
		lahirV = lahir.Time
	}
	if kawin.Valid {
		kawinV = kawin.Time
	}
	return &wargaArgs{args: []any{
		p.Nama, nullStr(p.NomorKK), nullStr(p.NIK), nullStr(p.Alamat), nullStr(p.HubunganKK),
		nullStr(p.JenisKelamin), nullStr(p.TempatLahir), lahirV, nullStr(p.Agama),
		nullStr(p.Pekerjaan), nullStr(p.GolDarah), nullStr(p.StatusKawin), kawinV,
	}}, ""
}

func isDigits(s string, n int) bool {
	if len(s) != n {
		return false
	}
	for _, c := range s {
		if c < '0' || c > '9' {
			return false
		}
	}
	return true
}

const wargaCols = `nama, nomor_kk, nik, alamat, hubungan_keluarga, jenis_kelamin, tempat_lahir,
	tanggal_lahir, agama, pekerjaan, gol_darah, status_kawin, tanggal_kawin`

// GET /api/warga?q=&limit=&offset=
func (s *Server) wargaList(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	limit, _ := strconv.Atoi(q.Get("limit"))
	if limit <= 0 || limit > 2000 {
		limit = 500
	}
	offset, _ := strconv.Atoi(q.Get("offset"))
	if offset < 0 {
		offset = 0
	}
	like := "%" + strings.TrimSpace(q.Get("q")) + "%"
	rows, err := s.queryMaps(r.Context(), `
		SELECT id, nama,
		  COALESCE(nomor_kk,'') AS "nomorKK", COALESCE(nik,'') AS nik, COALESCE(alamat,'') AS alamat,
		  COALESCE(hubungan_keluarga,'') AS "hubunganKK", COALESCE(jenis_kelamin,'') AS "jenisKelamin",
		  COALESCE(tempat_lahir,'') AS "tempatLahir", COALESCE(to_char(tanggal_lahir,'YYYY-MM-DD'),'') AS "tanggalLahir",
		  COALESCE(agama,'') AS agama, COALESCE(pekerjaan,'') AS pekerjaan, COALESCE(gol_darah,'') AS "golDarah",
		  COALESCE(status_kawin,'') AS "statusKawin", COALESCE(to_char(tanggal_kawin,'YYYY-MM-DD'),'') AS "tglKawin",
		  COALESCE(qr_url,'') AS "qrUrl", created_at AS "waktuInput"
		FROM warga
		WHERE nama ILIKE $1 OR COALESCE(nik,'') ILIKE $1 OR COALESCE(nomor_kk,'') ILIKE $1
		ORDER BY lower(nama) LIMIT $2 OFFSET $3`, like, limit, offset)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	writeJSON(w, http.StatusOK, rows)
}

// POST /api/warga
func (s *Server) wargaCreate(w http.ResponseWriter, r *http.Request) {
	var p wargaReq
	if !decode(w, r, &p, smallBody) {
		return
	}
	a, msg := p.prepare()
	if a == nil {
		fail(w, http.StatusBadRequest, msg)
		return
	}
	var id int64
	err := s.db.QueryRowContext(r.Context(), `INSERT INTO warga(`+wargaCols+`)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING id`, a.args...).Scan(&id)
	if isUnique(err) {
		fail(w, http.StatusConflict, "nama atau NIK sudah terdaftar")
		return
	}
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	okMsg(w, "Data berhasil ditambahkan!", map[string]any{"id": id})
}

// POST /api/warga/bulk  (simpanSemuaDataWargaKeSheet) - satu transaksi, duplikat dilewati.
func (s *Server) wargaBulk(w http.ResponseWriter, r *http.Request) {
	var in []wargaReq
	if !decode(w, r, &in, 5<<20) {
		return
	}
	if len(in) == 0 || len(in) > 2000 {
		fail(w, http.StatusBadRequest, "kirim 1-2000 data warga")
		return
	}
	prepared := make([]*wargaArgs, len(in))
	for i := range in {
		a, msg := in[i].prepare()
		if a == nil {
			fail(w, http.StatusBadRequest, "baris "+strconv.Itoa(i+1)+": "+msg)
			return
		}
		prepared[i] = a
	}
	tx, err := s.db.BeginTx(r.Context(), nil)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	defer tx.Rollback()
	stmt, err := tx.PrepareContext(r.Context(), `INSERT INTO warga(`+wargaCols+`)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) ON CONFLICT DO NOTHING`)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	defer stmt.Close()
	inserted := 0
	for _, a := range prepared {
		res, err := stmt.ExecContext(r.Context(), a.args...)
		if err != nil {
			s.serverErr(w, r, err)
			return
		}
		n, _ := res.RowsAffected()
		inserted += int(n)
	}
	if err := tx.Commit(); err != nil {
		s.serverErr(w, r, err)
		return
	}
	okMsg(w, "Berhasil menambahkan "+strconv.Itoa(inserted)+" data warga!",
		map[string]any{"ditambahkan": inserted, "dilewati": len(in) - inserted})
}

// PUT /api/warga/{id}
func (s *Server) wargaUpdate(w http.ResponseWriter, r *http.Request) {
	id, ok := idParam(w, r, "id")
	if !ok {
		return
	}
	var p wargaReq
	if !decode(w, r, &p, smallBody) {
		return
	}
	a, msg := p.prepare()
	if a == nil {
		fail(w, http.StatusBadRequest, msg)
		return
	}
	res, err := s.db.ExecContext(r.Context(), `UPDATE warga SET
		nama=$2, nomor_kk=$3, nik=$4, alamat=$5, hubungan_keluarga=$6, jenis_kelamin=$7, tempat_lahir=$8,
		tanggal_lahir=$9, agama=$10, pekerjaan=$11, gol_darah=$12, status_kawin=$13, tanggal_kawin=$14
		WHERE id=$1`, append([]any{id}, a.args...)...)
	if isUnique(err) {
		fail(w, http.StatusConflict, "nama atau NIK sudah dipakai warga lain")
		return
	}
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	if n, _ := res.RowsAffected(); n == 0 {
		fail(w, http.StatusNotFound, "warga tidak ditemukan")
		return
	}
	okMsg(w, "Data berhasil diperbarui!", nil)
}

// DELETE /api/warga/{id}  (angsuran & tunggakan ikut terhapus lewat ON DELETE CASCADE)
func (s *Server) wargaDelete(w http.ResponseWriter, r *http.Request) {
	id, ok := idParam(w, r, "id")
	if !ok {
		return
	}
	res, err := s.db.ExecContext(r.Context(), `DELETE FROM warga WHERE id=$1`, id)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	if n, _ := res.RowsAffected(); n == 0 {
		fail(w, http.StatusNotFound, "warga tidak ditemukan")
		return
	}
	okMsg(w, "Data berhasil dihapus!", nil)
}

// GET /api/warga/kartu  (getDataKartuWarga) - ringan, tanpa hitung tunggakan.
func (s *Server) wargaKartu(w http.ResponseWriter, r *http.Request) {
	rows, err := s.queryMaps(r.Context(), `
		SELECT id, nama, COALESCE(nik,'') AS nik, COALESCE(alamat,'') AS alamat, COALESCE(qr_url,'') AS "qrUrl"
		FROM warga ORDER BY lower(nama)`)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	writeJSON(w, http.StatusOK, rows)
}

// GET /api/rekap-kk  (REKAPKK)
func (s *Server) rekapKK(w http.ResponseWriter, r *http.Request) {
	rows, err := s.queryMaps(r.Context(), `
		SELECT nomor_kk AS "nomorKK", jumlah_anggota AS "jumlahAnggota",
		       COALESCE(kepala_keluarga,'') AS "kepalaKeluarga", COALESCE(alamat,'') AS alamat
		FROM v_rekap_kk ORDER BY nomor_kk`)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	writeJSON(w, http.StatusOK, rows)
}

var _ = sql.ErrNoRows
