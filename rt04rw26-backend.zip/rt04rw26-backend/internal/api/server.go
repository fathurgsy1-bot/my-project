// Package api berisi HTTP server REST (pengganti doGet/google.script.run Apps Script).
package api

import (
	"database/sql"
	"html/template"
	"log/slog"
	"net/http"
	"os"
	"path/filepath"
	"time"

	"github.com/rt04rw26/backend/internal/auth"
	"github.com/rt04rw26/backend/internal/config"
	"github.com/rt04rw26/backend/web"
)

type Server struct {
	db      *sql.DB
	cfg     *config.Config
	auth    *auth.Manager
	log     *slog.Logger
	limiter *rateLimiter
	cek     *template.Template
}

func New(db *sql.DB, cfg *config.Config, log *slog.Logger) (*Server, error) {
	for _, d := range []string{"qr", "kegiatan", "surat", "misc"} {
		if err := os.MkdirAll(filepath.Join(cfg.StorageDir, d), 0o755); err != nil {
			return nil, err
		}
	}
	t, err := template.New("cek").Parse(web.CekHTML)
	if err != nil {
		return nil, err
	}
	return &Server{
		db: db, cfg: cfg, log: log, cek: t,
		auth:    auth.NewManager(cfg.JWTSecret, cfg.TokenTTL),
		limiter: newRateLimiter(10, time.Minute),
	}, nil
}

const (
	roleAdmin      = "admin"
	roleBendahara  = "bendahara"
	roleSekretaris = "sekretaris"
	roleWarga      = "warga"
)

// Handler menyusun semua route dan middleware.
func (s *Server) Handler() http.Handler {
	mux := http.NewServeMux()

	// --- publik
	mux.HandleFunc("GET /healthz", s.health)
	mux.HandleFunc("POST /api/auth/register", s.register)
	mux.HandleFunc("POST /api/auth/login", s.login)
	mux.HandleFunc("GET /api/public/tunggakan/{token}", s.publicTunggakan)
	mux.HandleFunc("GET /cek/{token}", s.cekPage)
	mux.HandleFunc("GET /cek", s.cekLegacy) // kompatibel dengan ?mode=cek&token=...
	mux.Handle("GET /files/", s.filesHandler())

	// --- semua user yang login
	mux.Handle("GET /api/auth/me", s.guard(s.me))
	mux.Handle("GET /api/menu", s.guard(s.menu))

	// --- dashboard & tunggakan (pengurus)
	staff := []string{roleBendahara, roleSekretaris}
	mux.Handle("GET /api/dashboard/summary", s.guard(s.dashSummary, staff...))
	mux.Handle("GET /api/dashboard/charts", s.guard(s.dashCharts, staff...))
	mux.Handle("GET /api/dashboard/clients", s.guard(s.dashClients, staff...))
	mux.Handle("GET /api/tunggakan", s.guard(s.rekapHandler, staff...))
	mux.Handle("GET /api/tunggakan/warga", s.guard(s.tunggakanWargaList, staff...))
	mux.Handle("GET /api/tunggakan/warga/{id}", s.guard(s.tunggakanWargaDetail, staff...))
	mux.Handle("GET /api/tunggakan-lama", s.guard(s.tunggakanLamaList, roleBendahara))
	mux.Handle("PUT /api/tunggakan-lama/{wargaId}", s.guard(s.tunggakanLamaPut, roleBendahara))
	mux.Handle("GET /api/angsuran/{wargaId}", s.guard(s.angsuranList, roleBendahara))
	mux.Handle("PUT /api/angsuran/{wargaId}/{tahun}/{bulan}", s.guard(s.angsuranPut, roleBendahara))

	// --- kas (bendahara)
	mux.Handle("GET /api/kas", s.guard(s.kasList, roleBendahara))
	mux.Handle("POST /api/kas", s.guard(s.kasCreate, roleBendahara))
	mux.Handle("PUT /api/kas/{id}", s.guard(s.kasUpdate, roleBendahara))
	mux.Handle("DELETE /api/kas/{id}", s.guard(s.kasDelete, roleBendahara))
	mux.Handle("POST /api/kas/bayar", s.guard(s.kasBayar, roleBendahara))

	// --- warga, QR, KK (sekretaris)
	sek := roleSekretaris
	mux.Handle("GET /api/warga", s.guard(s.wargaList, sek, roleBendahara))
	mux.Handle("POST /api/warga", s.guard(s.wargaCreate, sek))
	mux.Handle("POST /api/warga/bulk", s.guard(s.wargaBulk, sek))
	mux.Handle("GET /api/warga/kartu", s.guard(s.wargaKartu, sek))
	mux.Handle("POST /api/warga/qr/bulk", s.guard(s.qrBulk, sek))
	mux.Handle("POST /api/warga/{id}/qr", s.guard(s.qrOne, sek))
	mux.Handle("PUT /api/warga/{id}", s.guard(s.wargaUpdate, sek))
	mux.Handle("DELETE /api/warga/{id}", s.guard(s.wargaDelete, sek))
	mux.Handle("GET /api/rekap-kk", s.guard(s.rekapKK, sek))

	// --- inventaris, surat, kegiatan, notulen, pertemuan (sekretaris)
	mux.Handle("GET /api/inventaris", s.guard(s.invList, sek))
	mux.Handle("POST /api/inventaris", s.guard(s.invCreate, sek))
	mux.Handle("PUT /api/inventaris/{id}", s.guard(s.invUpdate, sek))
	mux.Handle("DELETE /api/inventaris/{id}", s.guard(s.invDelete, sek))
	mux.Handle("GET /api/surat", s.guard(s.suratList, sek))
	mux.Handle("POST /api/surat", s.guard(s.suratCreate, sek))
	mux.Handle("GET /api/kegiatan", s.guard(s.kegList, sek))
	mux.Handle("POST /api/kegiatan", s.guard(s.kegCreate, sek))
	mux.Handle("PUT /api/kegiatan/{id}", s.guard(s.kegUpdate, sek))
	mux.Handle("DELETE /api/kegiatan/{id}", s.guard(s.kegDelete, sek))
	mux.Handle("GET /api/notulen", s.guard(s.notList, sek))
	mux.Handle("POST /api/notulen", s.guard(s.notCreate, sek))
	mux.Handle("PUT /api/notulen/{id}", s.guard(s.notUpdate, sek))
	mux.Handle("DELETE /api/notulen/{id}", s.guard(s.notDelete, sek))
	mux.Handle("GET /api/pertemuan", s.guard(s.pertList, sek, roleBendahara))
	mux.Handle("POST /api/pertemuan", s.guard(s.pertCreate, sek))
	mux.Handle("PUT /api/pertemuan/{id}", s.guard(s.pertUpdate, sek))
	mux.Handle("DELETE /api/pertemuan/{id}", s.guard(s.pertDelete, sek))
	mux.Handle("POST /api/upload", s.guard(s.upload, sek, roleBendahara))

	// --- manajemen user (admin saja; admin selalu lolos guard)
	mux.Handle("GET /api/users", s.guard(adminOnly(s.usersList)))
	mux.Handle("PUT /api/users/{id}", s.guard(adminOnly(s.usersUpdate)))
	mux.Handle("DELETE /api/users/{id}", s.guard(adminOnly(s.usersDelete)))

	var h http.Handler = mux
	h = s.cors(h)
	h = s.securityHeaders(h)
	h = s.logging(h)
	h = s.recoverer(h)
	return h
}

func (s *Server) health(w http.ResponseWriter, r *http.Request) {
	if err := s.db.PingContext(r.Context()); err != nil {
		fail(w, http.StatusServiceUnavailable, "database tidak dapat dihubungi")
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"status": "ok"})
}
