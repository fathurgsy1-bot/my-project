package api

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"net/http"
	"regexp"
	"strings"

	"github.com/rt04rw26/backend/internal/auth"
)

var usernameRe = regexp.MustCompile(`^[A-Za-z0-9_.@-]{3,50}$`)

type credentials struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

// POST /api/auth/register  (registerUser) - role selalu "warga".
func (s *Server) register(w http.ResponseWriter, r *http.Request) {
	if !s.limiter.allow("reg:" + s.clientIP(r)) {
		fail(w, http.StatusTooManyRequests, "terlalu banyak percobaan, coba lagi sebentar")
		return
	}
	var c credentials
	if !decode(w, r, &c, smallBody) {
		return
	}
	c.Username = strings.TrimSpace(c.Username)
	if !usernameRe.MatchString(c.Username) {
		fail(w, http.StatusBadRequest, "username 3-50 karakter: huruf, angka, titik, garis bawah, @ atau -")
		return
	}
	if err := auth.ValidatePassword(c.Password); err != nil {
		fail(w, http.StatusBadRequest, err.Error())
		return
	}
	hash, err := auth.HashPassword(c.Password)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	if _, err := s.db.ExecContext(r.Context(),
		`INSERT INTO users(username, password_hash, role) VALUES ($1,$2,'warga')`, c.Username, hash); err != nil {
		if isUnique(err) {
			fail(w, http.StatusConflict, "Username sudah terdaftar!")
			return
		}
		s.serverErr(w, r, err)
		return
	}
	okMsg(w, "Pendaftaran berhasil! Silakan login.", nil)
}

// POST /api/auth/login  (loginUser)
func (s *Server) login(w http.ResponseWriter, r *http.Request) {
	if !s.limiter.allow("login:" + s.clientIP(r)) {
		fail(w, http.StatusTooManyRequests, "terlalu banyak percobaan, coba lagi sebentar")
		return
	}
	var c credentials
	if !decode(w, r, &c, smallBody) {
		return
	}
	var id int64
	var uname, hash, role string
	err := s.db.QueryRowContext(r.Context(),
		`SELECT id, username, password_hash, role FROM users WHERE lower(btrim(username)) = lower(btrim($1))`,
		c.Username).Scan(&id, &uname, &hash, &role)
	if errors.Is(err, sql.ErrNoRows) {
		auth.DummyCheck(c.Password)
		fail(w, http.StatusUnauthorized, "Username atau Password salah!")
		return
	}
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	ok, rehash := auth.CheckPassword(c.Password, hash)
	if !ok {
		fail(w, http.StatusUnauthorized, "Username atau Password salah!")
		return
	}
	if rehash { // upgrade hash SHA-256 lama hasil impor dari Sheets
		if nh, err := auth.HashPassword(c.Password); err == nil {
			_, _ = s.db.ExecContext(r.Context(), `UPDATE users SET password_hash=$1 WHERE id=$2`, nh, id)
		}
	}
	tok, exp, err := s.auth.Issue(id, uname, role)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	okMsg(w, "Login Berhasil!", map[string]any{
		"token": tok, "expiresAt": exp, "role": role, "username": uname,
	})
}

func (s *Server) me(w http.ResponseWriter, r *http.Request) {
	u := userFrom(r)
	writeJSON(w, http.StatusOK, map[string]any{"id": u.ID, "username": u.Username, "role": u.Role})
}

// ---------------------------------------------------------------- menu & role

type resource struct {
	Key   string   // path REST
	Name  string   // nama sheet lama
	Table string   // tabel/view (konstanta, aman dari injeksi)
	Roles []string // peran selain admin yang boleh melihat
}

// Setara getSheetNames(role): admin semua; bendahara KAS & TUNGGAKAN;
// sekretaris REKAPKK, KEGIATAN, NOTULEN, WARGA, INVENTARIS (+ SURAT, UNDANGAN).
var resources = []resource{
	{"users", "ADMIN", "users", nil},
	{"warga", "WARGA", "warga", []string{roleSekretaris}},
	{"rekap-kk", "REKAPKK", "v_rekap_kk", []string{roleSekretaris}},
	{"kegiatan", "KEGIATAN", "kegiatan", []string{roleSekretaris}},
	{"notulen", "NOTULEN", "notulen", []string{roleSekretaris}},
	{"inventaris", "INVENTARIS", "inventaris", []string{roleSekretaris}},
	{"surat", "SURAT", "surat_pengantar", []string{roleSekretaris}},
	{"pertemuan", "UNDANGAN", "pertemuan", []string{roleSekretaris}},
	{"kas", "KAS", "kas", []string{roleBendahara}},
	{"tunggakan-lama", "TUNGGAKAN", "tunggakan_lama", []string{roleBendahara}},
	{"angsuran", "ANGSURAN", "angsuran", nil},
}

func visibleResources(role string) []resource {
	var out []resource
	for _, rs := range resources {
		if role == roleAdmin {
			out = append(out, rs)
			continue
		}
		for _, ro := range rs.Roles {
			if ro == role {
				out = append(out, rs)
				break
			}
		}
	}
	return out
}

// GET /api/menu
func (s *Server) menu(w http.ResponseWriter, r *http.Request) {
	list := []map[string]string{}
	for _, rs := range visibleResources(userFrom(r).Role) {
		list = append(list, map[string]string{"key": rs.Key, "name": rs.Name})
	}
	writeJSON(w, http.StatusOK, list)
}

// ------------------------------------------------------------------ users (admin)

func (s *Server) usersList(w http.ResponseWriter, r *http.Request) {
	rows, err := s.queryMaps(r.Context(),
		`SELECT id, username, role, created_at AS "createdAt" FROM users ORDER BY lower(username)`)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	writeJSON(w, http.StatusOK, rows)
}

func (s *Server) usersUpdate(w http.ResponseWriter, r *http.Request) {
	id, ok := idParam(w, r, "id")
	if !ok {
		return
	}
	var in struct {
		Role     string `json:"role"`
		Password string `json:"password"`
	}
	if !decode(w, r, &in, smallBody) {
		return
	}
	if in.Role != "" {
		switch in.Role {
		case roleAdmin, roleBendahara, roleSekretaris, roleWarga:
		default:
			fail(w, http.StatusBadRequest, "role tidak valid")
			return
		}
		if id == userFrom(r).ID && in.Role != roleAdmin {
			fail(w, http.StatusBadRequest, "tidak bisa menurunkan role akun sendiri")
			return
		}
	}
	if in.Password != "" {
		if err := auth.ValidatePassword(in.Password); err != nil {
			fail(w, http.StatusBadRequest, err.Error())
			return
		}
	}
	var hash any
	if in.Password != "" {
		h, err := auth.HashPassword(in.Password)
		if err != nil {
			s.serverErr(w, r, err)
			return
		}
		hash = h
	}
	res, err := s.db.ExecContext(r.Context(),
		`UPDATE users SET role = COALESCE(NULLIF($2,''), role), password_hash = COALESCE($3, password_hash) WHERE id=$1`,
		id, in.Role, hash)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	if n, _ := res.RowsAffected(); n == 0 {
		fail(w, http.StatusNotFound, "user tidak ditemukan")
		return
	}
	okMsg(w, "Data berhasil diperbarui!", nil)
}

func (s *Server) usersDelete(w http.ResponseWriter, r *http.Request) {
	id, ok := idParam(w, r, "id")
	if !ok {
		return
	}
	if id == userFrom(r).ID {
		fail(w, http.StatusBadRequest, "tidak bisa menghapus akun sendiri")
		return
	}
	res, err := s.db.ExecContext(r.Context(), `DELETE FROM users WHERE id=$1`, id)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	if n, _ := res.RowsAffected(); n == 0 {
		fail(w, http.StatusNotFound, "user tidak ditemukan")
		return
	}
	okMsg(w, "Data berhasil dihapus!", nil)
}

// EnsureAdmin membuat akun admin awal dari ADMIN_USERNAME/ADMIN_PASSWORD,
// hanya bila belum ada satu pun admin.
func (s *Server) EnsureAdmin(ctx context.Context) error {
	if s.cfg.AdminUser == "" || s.cfg.AdminPass == "" {
		return nil
	}
	var n int
	if err := s.db.QueryRowContext(ctx, `SELECT count(*) FROM users WHERE role='admin'`).Scan(&n); err != nil {
		return err
	}
	if n > 0 {
		return nil
	}
	if !usernameRe.MatchString(s.cfg.AdminUser) {
		return errors.New("ADMIN_USERNAME tidak valid")
	}
	if err := auth.ValidatePassword(s.cfg.AdminPass); err != nil {
		return fmt.Errorf("ADMIN_PASSWORD: %w", err)
	}
	hash, err := auth.HashPassword(s.cfg.AdminPass)
	if err != nil {
		return err
	}
	_, err = s.db.ExecContext(ctx,
		`INSERT INTO users(username, password_hash, role) VALUES ($1,$2,'admin')`, s.cfg.AdminUser, hash)
	if err == nil {
		s.log.Info("akun admin awal dibuat", "username", s.cfg.AdminUser)
	}
	return err
}
