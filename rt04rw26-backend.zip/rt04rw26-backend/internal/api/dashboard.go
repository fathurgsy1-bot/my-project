package api

import (
	"net/http"
	"strconv"

	"github.com/rt04rw26/backend/internal/arrears"
)

// counts menghitung jumlah baris tiap resource yang boleh dilihat role.
// Nama tabel berasal dari konstanta `resources`, bukan dari input pengguna.
func (s *Server) counts(r *http.Request) ([]map[string]any, error) {
	out := []map[string]any{}
	for _, rs := range visibleResources(userFrom(r).Role) {
		var n int
		if err := s.db.QueryRowContext(r.Context(), `SELECT count(*) FROM `+rs.Table).Scan(&n); err != nil {
			return nil, err
		}
		out = append(out, map[string]any{"key": rs.Key, "name": rs.Name, "count": n})
	}
	return out, nil
}

// GET /api/dashboard/summary  (getDashboardSummary)
func (s *Server) dashSummary(w http.ResponseWriter, r *http.Request) {
	c, err := s.counts(r)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	writeJSON(w, http.StatusOK, c)
}

// GET /api/dashboard/charts?tahun=  (getDashboardDataForCharts)
func (s *Server) dashCharts(w http.ResponseWriter, r *http.Request) {
	c, err := s.counts(r)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	labels, data := []string{}, []int{}
	for _, x := range c {
		labels = append(labels, x["name"].(string))
		data = append(data, x["count"].(int))
	}
	tahun, _ := strconv.Atoi(r.URL.Query().Get("tahun"))
	if tahun == 0 {
		tahun = s.now().Year()
	}
	masuk, keluar := make([]int64, 12), make([]int64, 12)
	rows, err := s.db.QueryContext(r.Context(),
		`SELECT bulan, SUM(debet), SUM(kredit) FROM kas WHERE tahun=$1 GROUP BY bulan`, tahun)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	defer rows.Close()
	for rows.Next() {
		var b int
		var d, k int64
		if err := rows.Scan(&b, &d, &k); err != nil {
			s.serverErr(w, r, err)
			return
		}
		masuk[b-1], keluar[b-1] = d, k
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"sheetStats": map[string]any{"labels": labels, "data": data},
		"kasData":    map[string]any{"labels": arrears.BulanList, "masuk": masuk, "keluar": keluar, "tahun": tahun},
	})
}
