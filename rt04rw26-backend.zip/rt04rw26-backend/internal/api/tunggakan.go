package api

import (
	"context"
	"database/sql"
	"errors"
	"net/http"
	"strconv"
	"strings"

	"github.com/rt04rw26/backend/internal/arrears"
)

// loadInputs memuat data tunggakan lama + angsuran tahun berjalan.
// onlyID > 0 -> hanya satu warga.
func (s *Server) loadInputs(ctx context.Context, year int, onlyID int64) ([]arrears.Input, error) {
	rows, err := s.db.QueryContext(ctx, `
		SELECT w.id, w.nama, COALESCE(t.nominal,0), COALESCE(t.catatan,'')
		FROM warga w LEFT JOIN tunggakan_lama t ON t.warga_id = w.id
		WHERE ($1 = 0 OR w.id = $1)
		ORDER BY lower(w.nama)`, onlyID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var inputs []arrears.Input
	idx := map[int64]int{}
	for rows.Next() {
		var in arrears.Input
		if err := rows.Scan(&in.WargaID, &in.Nama, &in.Lama, &in.CatatanLama); err != nil {
			return nil, err
		}
		in.Bulan = map[int]arrears.MonthPay{}
		idx[in.WargaID] = len(inputs)
		inputs = append(inputs, in)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}

	ar, err := s.db.QueryContext(ctx, `
		SELECT warga_id, bulan, bayar, catatan FROM angsuran
		WHERE tahun = $1 AND ($2 = 0 OR warga_id = $2)`, year, onlyID)
	if err != nil {
		return nil, err
	}
	defer ar.Close()
	for ar.Next() {
		var wid int64
		var bulan int
		var mp arrears.MonthPay
		if err := ar.Scan(&wid, &bulan, &mp.Bayar, &mp.Catatan); err != nil {
			return nil, err
		}
		if i, ok := idx[wid]; ok {
			inputs[i].Bulan[bulan] = mp
		}
	}
	return inputs, ar.Err()
}

// bulanIniSudahJatuhTempo: ada pertemuan (UNDANGAN) bulan ini yang tanggalnya <= hari ini.
// Bila ya, bulan berjalan ikut dihitung sebagai tunggakan.
func (s *Server) bulanIniSudahJatuhTempo(ctx context.Context) (bool, error) {
	now := s.now()
	first := now.Format("2006-01") + "-01"
	var due bool
	err := s.db.QueryRowContext(ctx,
		`SELECT EXISTS(SELECT 1 FROM pertemuan WHERE tanggal >= $1::date AND tanggal <= $2::date)`,
		first, now.Format("2006-01-02")).Scan(&due)
	return due, err
}

func (s *Server) batasBulan(ctx context.Context) (int, error) {
	due, err := s.bulanIniSudahJatuhTempo(ctx)
	if err != nil {
		return 0, err
	}
	b := int(s.now().Month()) - 1
	if due {
		b++
	}
	return b, nil
}

func (s *Server) rekap(ctx context.Context) ([]arrears.Row, int, error) {
	batas, err := s.batasBulan(ctx)
	if err != nil {
		return nil, 0, err
	}
	in, err := s.loadInputs(ctx, s.now().Year(), 0)
	if err != nil {
		return nil, 0, err
	}
	return arrears.ComputeAll(in, batas, s.cfg.FeePerMonth), batas, nil
}

// GET /api/tunggakan  (getRekapTunggakan)
func (s *Server) rekapHandler(w http.ResponseWriter, r *http.Request) {
	rows, batas, err := s.rekap(r.Context())
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	var total int64
	for _, x := range rows {
		total += x.Total
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"tahun": s.now().Year(), "bulanDihitung": batas, "biayaPerBulan": s.cfg.FeePerMonth,
		"totalSemua": total, "rows": rows,
	})
}

// GET /api/dashboard/clients  (getInitialData: bulan 1..bulan berjalan)
func (s *Server) dashClients(w http.ResponseWriter, r *http.Request) {
	in, err := s.loadInputs(r.Context(), s.now().Year(), 0)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	out := make([]map[string]any, 0, len(in))
	for _, x := range arrears.ComputeAll(in, int(s.now().Month()), s.cfg.FeePerMonth) {
		out = append(out, map[string]any{"id": x.WargaID, "name": x.Nama, "tunggakan": x.Total})
	}
	writeJSON(w, http.StatusOK, out)
}

type wargaDetail struct {
	ID      int64            `json:"id,omitempty"`
	Nama    string           `json:"nama"`
	NIK     string           `json:"nik"`
	Alamat  string           `json:"alamat"`
	Total   int64            `json:"total"`
	Rincian []arrears.Detail `json:"rincian"`
	Catatan string           `json:"catatan"`
}

var errNotFound = errors.New("tidak ditemukan")

// detailWarga membangun detail tunggakan satu warga (getDetailTunggakanWarga).
func (s *Server) detailWarga(ctx context.Context, where string, arg any) (*wargaDetail, error) {
	var d wargaDetail
	// `where` hanya konstanta dari pemanggil internal ("id" / "access_token").
	err := s.db.QueryRowContext(ctx,
		`SELECT id, nama, COALESCE(nik,''), COALESCE(alamat,'') FROM warga WHERE `+where+` = $1`, arg).
		Scan(&d.ID, &d.Nama, &d.NIK, &d.Alamat)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, errNotFound
	}
	if err != nil {
		return nil, err
	}
	batas, err := s.batasBulan(ctx)
	if err != nil {
		return nil, err
	}
	in, err := s.loadInputs(ctx, s.now().Year(), d.ID)
	if err != nil {
		return nil, err
	}
	if len(in) == 1 {
		row := arrears.Compute(in[0], batas, s.cfg.FeePerMonth)
		d.Total, d.Rincian, d.Catatan = row.Total, row.Rincian, row.Catatan
	}
	if d.Rincian == nil {
		d.Rincian = []arrears.Detail{}
	}
	return &d, nil
}

// GET /api/tunggakan/warga/{id}
func (s *Server) tunggakanWargaDetail(w http.ResponseWriter, r *http.Request) {
	id, ok := idParam(w, r, "id")
	if !ok {
		return
	}
	d, err := s.detailWarga(r.Context(), "id", id)
	if errors.Is(err, errNotFound) {
		fail(w, http.StatusNotFound, "warga tidak ditemukan")
		return
	}
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	writeJSON(w, http.StatusOK, d)
}

// GET /api/tunggakan/warga  (getWargaTunggakanList)
func (s *Server) tunggakanWargaList(w http.ResponseWriter, r *http.Request) {
	rows, _, err := s.rekap(r.Context())
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	totals := map[int64]int64{}
	for _, x := range rows {
		totals[x.WargaID] = x.Total
	}
	list, err := s.queryMaps(r.Context(),
		`SELECT id, nama, COALESCE(nik,'') AS nik, COALESCE(alamat,'') AS alamat FROM warga ORDER BY lower(nama)`)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	for _, m := range list {
		m["totalTunggakan"] = totals[m["id"].(int64)]
	}
	writeJSON(w, http.StatusOK, list)
}

// GET /api/public/tunggakan/{token}  (getDetailTunggakanByAccessToken) - tanpa login.
func (s *Server) publicTunggakan(w http.ResponseWriter, r *http.Request) {
	tok := strings.TrimSpace(r.PathValue("token"))
	if len(tok) < 16 {
		fail(w, http.StatusNotFound, "Kartu/QR tidak dikenali.")
		return
	}
	d, err := s.detailWarga(r.Context(), "access_token", tok)
	if errors.Is(err, errNotFound) {
		fail(w, http.StatusNotFound, "Kartu/QR tidak dikenali.")
		return
	}
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	d.ID = 0 // jangan bocorkan id internal di jalur publik
	w.Header().Set("Cache-Control", "no-store")
	writeJSON(w, http.StatusOK, d)
}

// ------------------------------------------------- tunggakan lama & angsuran

// GET /api/tunggakan-lama
func (s *Server) tunggakanLamaList(w http.ResponseWriter, r *http.Request) {
	rows, err := s.queryMaps(r.Context(), `
		SELECT w.id AS "wargaId", w.nama, COALESCE(t.nominal,0) AS nominal, COALESCE(t.catatan,'') AS catatan
		FROM warga w LEFT JOIN tunggakan_lama t ON t.warga_id = w.id ORDER BY lower(w.nama)`)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	writeJSON(w, http.StatusOK, rows)
}

// PUT /api/tunggakan-lama/{wargaId}
func (s *Server) tunggakanLamaPut(w http.ResponseWriter, r *http.Request) {
	id, ok := idParam(w, r, "wargaId")
	if !ok {
		return
	}
	var in struct {
		Nominal flexInt `json:"nominal"`
		Catatan string  `json:"catatan"`
	}
	if !decode(w, r, &in, smallBody) {
		return
	}
	if in.Nominal < 0 {
		fail(w, http.StatusBadRequest, "nominal tidak boleh negatif")
		return
	}
	_, err := s.db.ExecContext(r.Context(), `
		INSERT INTO tunggakan_lama(warga_id, nominal, catatan) VALUES ($1,$2,$3)
		ON CONFLICT (warga_id) DO UPDATE SET nominal=EXCLUDED.nominal, catatan=EXCLUDED.catatan`,
		id, int64(in.Nominal), strings.TrimSpace(in.Catatan))
	if isPgCode(err, "23503") {
		fail(w, http.StatusNotFound, "warga tidak ditemukan")
		return
	}
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	okMsg(w, "Data berhasil diperbarui!", nil)
}

// GET /api/angsuran/{wargaId}?tahun=2026
func (s *Server) angsuranList(w http.ResponseWriter, r *http.Request) {
	id, ok := idParam(w, r, "wargaId")
	if !ok {
		return
	}
	tahun, _ := strconv.Atoi(r.URL.Query().Get("tahun"))
	if tahun == 0 {
		tahun = s.now().Year()
	}
	rows, err := s.queryMaps(r.Context(),
		`SELECT tahun, bulan, bayar, catatan FROM angsuran WHERE warga_id=$1 AND tahun=$2 ORDER BY bulan`, id, tahun)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	writeJSON(w, http.StatusOK, rows)
}

// PUT /api/angsuran/{wargaId}/{tahun}/{bulan}  (koreksi manual sel ANGSURAN)
func (s *Server) angsuranPut(w http.ResponseWriter, r *http.Request) {
	id, ok := idParam(w, r, "wargaId")
	if !ok {
		return
	}
	tahun, err1 := strconv.Atoi(r.PathValue("tahun"))
	bulan, err2 := strconv.Atoi(r.PathValue("bulan"))
	if err1 != nil || err2 != nil || tahun < 2000 || tahun > 2100 || bulan < 1 || bulan > 12 {
		fail(w, http.StatusBadRequest, "tahun/bulan tidak valid")
		return
	}
	var in struct {
		Bayar   flexInt `json:"bayar"`
		Catatan string  `json:"catatan"`
	}
	if !decode(w, r, &in, smallBody) {
		return
	}
	if in.Bayar < 0 {
		fail(w, http.StatusBadRequest, "nominal tidak boleh negatif")
		return
	}
	_, err := s.db.ExecContext(r.Context(), `
		INSERT INTO angsuran(warga_id, tahun, bulan, bayar, catatan) VALUES ($1,$2,$3,$4,$5)
		ON CONFLICT (warga_id, tahun, bulan) DO UPDATE SET bayar=EXCLUDED.bayar, catatan=EXCLUDED.catatan`,
		id, tahun, bulan, int64(in.Bayar), strings.TrimSpace(in.Catatan))
	if isPgCode(err, "23503") {
		fail(w, http.StatusNotFound, "warga tidak ditemukan")
		return
	}
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	okMsg(w, "Data berhasil diperbarui!", nil)
}
