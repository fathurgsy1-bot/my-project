package api

import (
	"crypto/rand"
	"encoding/base64"
	"encoding/hex"
	"errors"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"

	qrcode "github.com/skip2/go-qrcode"
)

const maxUpload = 8 << 20 // 8 MiB

var allowedFolders = map[string]bool{"kegiatan": true, "surat": true, "misc": true}

// ext berdasarkan isi file (bukan nama/ekstensi dari klien).
var allowedTypes = map[string]string{
	"image/png": ".png", "image/jpeg": ".jpg", "image/gif": ".gif", "image/webp": ".webp",
	"application/pdf": ".pdf",
}

func randomHex(n int) (string, error) {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return hex.EncodeToString(b), nil
}

// saveBytes memvalidasi tipe file lalu menyimpannya dengan nama acak. Mengembalikan URL publik.
func (s *Server) saveBytes(folder string, data []byte) (string, error) {
	if !allowedFolders[folder] {
		return "", errors.New("folder tidak valid")
	}
	if len(data) == 0 || len(data) > maxUpload {
		return "", errors.New("ukuran file harus 1 byte - 8 MB")
	}
	ext, ok := allowedTypes[http.DetectContentType(data)]
	if !ok {
		return "", errors.New("tipe file tidak didukung (png, jpg, gif, webp, pdf)")
	}
	name, err := randomHex(12)
	if err != nil {
		return "", err
	}
	if err := os.WriteFile(filepath.Join(s.cfg.StorageDir, folder, name+ext), data, 0o644); err != nil {
		return "", err
	}
	return s.cfg.PublicBaseURL + "/files/" + folder + "/" + name + ext, nil
}

// saveDataURL: pengganti uploadBase64ToDrive / processBase64Uploads.
func (s *Server) saveDataURL(folder, dataURL string) (string, error) {
	_, b64, found := strings.Cut(dataURL, ",")
	if !found || !strings.HasPrefix(dataURL, "data:") {
		return "", errors.New("format data URL tidak valid")
	}
	data, err := base64.StdEncoding.DecodeString(b64)
	if err != nil {
		return "", errors.New("base64 tidak valid")
	}
	return s.saveBytes(folder, data)
}

// POST /api/upload  (multipart: file, folder)
func (s *Server) upload(w http.ResponseWriter, r *http.Request) {
	r.Body = http.MaxBytesReader(w, r.Body, maxUpload+1<<20)
	if err := r.ParseMultipartForm(maxUpload); err != nil {
		fail(w, http.StatusBadRequest, "upload tidak valid atau terlalu besar")
		return
	}
	f, _, err := r.FormFile("file")
	if err != nil {
		fail(w, http.StatusBadRequest, "field 'file' wajib ada")
		return
	}
	defer f.Close()
	data, err := io.ReadAll(io.LimitReader(f, maxUpload+1))
	if err != nil {
		fail(w, http.StatusBadRequest, "gagal membaca file")
		return
	}
	folder := r.FormValue("folder")
	if folder == "" {
		folder = "misc"
	}
	url, err := s.saveBytes(folder, data)
	if err != nil {
		fail(w, http.StatusBadRequest, err.Error())
		return
	}
	okMsg(w, "File berhasil diunggah", map[string]any{"url": url})
}

// ---------------------------------------------------------------- static files

type noDirFS struct{ fs http.FileSystem }

func (n noDirFS) Open(name string) (http.File, error) {
	f, err := n.fs.Open(name)
	if err != nil {
		return nil, err
	}
	st, err := f.Stat()
	if err != nil || st.IsDir() { // tolak listing direktori
		f.Close()
		return nil, os.ErrNotExist
	}
	return f, nil
}

func (s *Server) filesHandler() http.Handler {
	fsrv := http.StripPrefix("/files/", http.FileServer(noDirFS{http.Dir(s.cfg.StorageDir)}))
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Cache-Control", "public, max-age=86400")
		w.Header().Set("Content-Security-Policy", "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'")
		fsrv.ServeHTTP(w, r)
	})
}

// ------------------------------------------------------------------------- QR

// ensureToken: token akses acak per warga. Bila sudah ada, TIDAK diganti
// (QR lama tetap valid), sama seperti pastikanAccessTokenWarga.
func (s *Server) ensureToken(r *http.Request, id int64) (token, nama string, err error) {
	fresh, err := randomHex(16)
	if err != nil {
		return "", "", err
	}
	err = s.db.QueryRowContext(r.Context(), `
		UPDATE warga SET access_token = COALESCE(access_token, $2) WHERE id=$1
		RETURNING access_token, nama`, id, fresh).Scan(&token, &nama)
	return
}

type qrResult struct {
	ID      int64  `json:"id"`
	Nama    string `json:"nama"`
	Success bool   `json:"success"`
	URL     string `json:"url,omitempty"`
	Message string `json:"message"`
}

func (s *Server) buatQR(r *http.Request, id int64) qrResult {
	res := qrResult{ID: id}
	token, nama, err := s.ensureToken(r, id)
	if err != nil {
		res.Message = "warga tidak ditemukan"
		return res
	}
	res.Nama = nama
	png, err := qrcode.Encode(s.cfg.PublicBaseURL+"/cek/"+token, qrcode.Medium, 600)
	if err != nil {
		res.Message = "gagal membuat QR"
		return res
	}
	if err := os.WriteFile(filepath.Join(s.cfg.StorageDir, "qr", token+".png"), png, 0o644); err != nil {
		s.log.Error("tulis QR", "err", err)
		res.Message = "gagal menyimpan QR"
		return res
	}
	url := s.cfg.PublicBaseURL + "/files/qr/" + token + ".png"
	if _, err := s.db.ExecContext(r.Context(), `UPDATE warga SET qr_url=$2 WHERE id=$1`, id, url); err != nil {
		res.Message = "gagal menyimpan URL QR"
		return res
	}
	res.Success, res.URL = true, url
	res.Message = "QR untuk " + nama + " berhasil dibuat & disimpan."
	return res
}

// POST /api/warga/{id}/qr  (generateDanSimpanQRWarga)
func (s *Server) qrOne(w http.ResponseWriter, r *http.Request) {
	id, ok := idParam(w, r, "id")
	if !ok {
		return
	}
	res := s.buatQR(r, id)
	if !res.Success {
		fail(w, http.StatusNotFound, res.Message)
		return
	}
	writeJSON(w, http.StatusOK, res)
}

// POST /api/warga/qr/bulk  (generateQRBulkSemuaWarga)
func (s *Server) qrBulk(w http.ResponseWriter, r *http.Request) {
	rows, err := s.db.QueryContext(r.Context(), `SELECT id FROM warga ORDER BY id`)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	var ids []int64
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			rows.Close()
			s.serverErr(w, r, err)
			return
		}
		ids = append(ids, id)
	}
	rows.Close()
	detail := make([]qrResult, 0, len(ids))
	sukses := 0
	for _, id := range ids {
		res := s.buatQR(r, id)
		if res.Success {
			sukses++
		}
		detail = append(detail, res)
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"success": true, "total": len(ids), "sukses": sukses, "gagal": len(ids) - sukses, "detail": detail,
	})
}
