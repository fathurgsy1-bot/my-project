package api

import (
	"errors"
	"net/http"
	"net/url"
	"strconv"
	"strings"

	"github.com/rt04rw26/backend/internal/arrears"
)

type cekItem struct {
	Label   string
	Catatan string
}

type cekView struct {
	Error     string
	Wilayah   string
	WargaID   int64
	Nama      string
	Alamat    string
	TotalFmt  string
	Lunas     bool
	Tunggakan []cekItem
	Catatan   []cekItem
	BulanList []string
	BulanNow  string
	TahunList []int
	TahunNow  int
}

// rupiah memformat 1500000 -> "Rp 1.500.000" (id-ID).
func rupiah(n int64) string {
	neg := n < 0
	if neg {
		n = -n
	}
	s := strconv.FormatInt(n, 10)
	var b strings.Builder
	for i, c := range s {
		if i > 0 && (len(s)-i)%3 == 0 {
			b.WriteByte('.')
		}
		b.WriteRune(c)
	}
	if neg {
		return "-Rp " + b.String()
	}
	return "Rp " + b.String()
}

func (s *Server) renderCek(w http.ResponseWriter, status int, v cekView) {
	v.Wilayah = s.cfg.Wilayah
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("X-Robots-Tag", "noindex, nofollow")
	// Halaman memakai script inline milik sendiri; batasi sumber lain.
	w.Header().Set("Content-Security-Policy",
		"default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'self'; base-uri 'none'; form-action 'none'")
	w.WriteHeader(status)
	if err := s.cek.Execute(w, v); err != nil {
		s.log.Error("render cek", "err", err)
	}
}

// GET /cek/{token}  (renderCekTunggakanPage) - publik, hanya valid bila token benar.
func (s *Server) cekPage(w http.ResponseWriter, r *http.Request) {
	tok := strings.TrimSpace(r.PathValue("token"))
	if len(tok) < 16 {
		s.renderCek(w, http.StatusNotFound, cekView{Error: "Kartu/QR tidak dikenali."})
		return
	}
	d, err := s.detailWarga(r.Context(), "access_token", tok)
	if errors.Is(err, errNotFound) {
		s.renderCek(w, http.StatusNotFound, cekView{Error: "Kartu/QR tidak dikenali."})
		return
	}
	if err != nil {
		s.log.Error("cek", "err", err)
		s.renderCek(w, http.StatusInternalServerError, cekView{Error: "Terjadi kesalahan pada server."})
		return
	}
	v := cekView{
		WargaID: d.ID, Nama: d.Nama, Alamat: d.Alamat, TotalFmt: rupiah(d.Total), Lunas: d.Total == 0,
		BulanList: arrears.BulanList, BulanNow: arrears.BulanList[int(s.now().Month())-1], TahunNow: s.now().Year(),
	}
	for y := v.TahunNow - 1; y <= v.TahunNow+2; y++ {
		v.TahunList = append(v.TahunList, y)
	}
	for _, x := range d.Rincian {
		if x.Info {
			v.Catatan = append(v.Catatan, cekItem{x.Label, x.Catatan})
		} else {
			v.Tunggakan = append(v.Tunggakan, cekItem{x.Label, x.Catatan})
		}
	}
	s.renderCek(w, http.StatusOK, v)
}

// GET /cek?token=...  atau  /cek?mode=cek&token=...  (tautan QR versi lama)
func (s *Server) cekLegacy(w http.ResponseWriter, r *http.Request) {
	tok := strings.TrimSpace(r.URL.Query().Get("token"))
	if tok == "" {
		s.renderCek(w, http.StatusNotFound, cekView{Error: "Link tidak valid. Silakan scan ulang QR Code Anda."})
		return
	}
	http.Redirect(w, r, "/cek/"+url.PathEscape(tok), http.StatusFound)
}
