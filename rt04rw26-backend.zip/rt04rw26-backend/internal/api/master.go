package api

import (
	"net/http"
	"strings"
)

// Helper kecil: jalankan Exec lalu balas 404 bila tidak ada baris yang terpengaruh.
func (s *Server) execOne(w http.ResponseWriter, r *http.Request, okText, query string, args ...any) {
	res, err := s.db.ExecContext(r.Context(), query, args...)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	if n, _ := res.RowsAffected(); n == 0 {
		fail(w, http.StatusNotFound, "data tidak ditemukan")
		return
	}
	okMsg(w, okText, nil)
}

// ------------------------------------------------------------------ inventaris

type invReq struct {
	NamaBarang string  `json:"namaBarang"`
	Kategori   string  `json:"kategori"`
	Kondisi    string  `json:"kondisi"`
	Lokasi     string  `json:"lokasi"`
	Jumlah     flexInt `json:"jumlah"`
	Keterangan string  `json:"keterangan"`
}

func (p *invReq) validate() string {
	p.NamaBarang = strings.TrimSpace(p.NamaBarang)
	if p.NamaBarang == "" {
		return "namaBarang wajib diisi"
	}
	if p.Jumlah < 0 {
		return "jumlah tidak boleh negatif"
	}
	return ""
}

// GET /api/inventaris
func (s *Server) invList(w http.ResponseWriter, r *http.Request) {
	rows, err := s.queryMaps(r.Context(), `
		SELECT id, kode_barang AS "kodeBarang", nama_barang AS "namaBarang", kategori, kondisi,
		       lokasi, jumlah, keterangan, created_at AS "waktuInput"
		FROM inventaris ORDER BY id`)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	writeJSON(w, http.StatusOK, rows)
}

// POST /api/inventaris  (addInventarisItem) - kode INV-0001 dibuat otomatis oleh DB.
func (s *Server) invCreate(w http.ResponseWriter, r *http.Request) {
	var p invReq
	if !decode(w, r, &p, smallBody) {
		return
	}
	if m := p.validate(); m != "" {
		fail(w, http.StatusBadRequest, m)
		return
	}
	var kode string
	err := s.db.QueryRowContext(r.Context(), `
		INSERT INTO inventaris(nama_barang, kategori, kondisi, lokasi, jumlah, keterangan)
		VALUES ($1,$2,$3,$4,$5,$6) RETURNING kode_barang`,
		p.NamaBarang, strings.TrimSpace(p.Kategori), strings.TrimSpace(p.Kondisi),
		strings.TrimSpace(p.Lokasi), int64(p.Jumlah), strings.TrimSpace(p.Keterangan)).Scan(&kode)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	okMsg(w, "Barang berhasil ditambahkan ke inventaris.", map[string]any{"kodeBarang": kode})
}

// PUT /api/inventaris/{id}  (editInventarisItem)
func (s *Server) invUpdate(w http.ResponseWriter, r *http.Request) {
	id, ok := idParam(w, r, "id")
	if !ok {
		return
	}
	var p invReq
	if !decode(w, r, &p, smallBody) {
		return
	}
	if m := p.validate(); m != "" {
		fail(w, http.StatusBadRequest, m)
		return
	}
	s.execOne(w, r, "Data barang berhasil diperbarui.", `
		UPDATE inventaris SET nama_barang=$2, kategori=$3, kondisi=$4, lokasi=$5, jumlah=$6, keterangan=$7 WHERE id=$1`,
		id, p.NamaBarang, strings.TrimSpace(p.Kategori), strings.TrimSpace(p.Kondisi),
		strings.TrimSpace(p.Lokasi), int64(p.Jumlah), strings.TrimSpace(p.Keterangan))
}

// DELETE /api/inventaris/{id}
func (s *Server) invDelete(w http.ResponseWriter, r *http.Request) {
	if id, ok := idParam(w, r, "id"); ok {
		s.execOne(w, r, "Data berhasil dihapus!", `DELETE FROM inventaris WHERE id=$1`, id)
	}
}

// ---------------------------------------------------------------------- surat

type suratReq struct {
	NomorSurat string `json:"nomorSurat"`
	WargaID    int64  `json:"wargaId"`
	Nama       string `json:"nama"`
	NIK        string `json:"nik"`
	Alamat     string `json:"alamat"`
	Keperluan  string `json:"keperluan"`
	FileURL    string `json:"fileUrl"`
	FileBase64 string `json:"fileBase64"` // opsional: data URL (png/jpg/pdf)
}

// GET /api/surat
func (s *Server) suratList(w http.ResponseWriter, r *http.Request) {
	rows, err := s.queryMaps(r.Context(), `
		SELECT id, tanggal, nomor_surat AS "nomorSurat", nama, nik, alamat, keperluan,
		       status_surat AS "statusSurat", file_url AS "fileUrl"
		FROM surat_pengantar ORDER BY tanggal DESC, id DESC`)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	writeJSON(w, http.StatusOK, rows)
}

// POST /api/surat  (simpanSuratPengantar) - status otomatis "Terbit".
func (s *Server) suratCreate(w http.ResponseWriter, r *http.Request) {
	var p suratReq
	if !decode(w, r, &p, 12<<20) {
		return
	}
	p.Nama = strings.TrimSpace(p.Nama)
	if p.Nama == "" {
		fail(w, http.StatusBadRequest, "nama wajib diisi")
		return
	}
	fileURL := strings.TrimSpace(p.FileURL)
	if p.FileBase64 != "" {
		u, err := s.saveDataURL("surat", p.FileBase64)
		if err != nil {
			fail(w, http.StatusBadRequest, err.Error())
			return
		}
		fileURL = u
	}
	var wid any
	if p.WargaID > 0 {
		wid = p.WargaID
	}
	var id int64
	err := s.db.QueryRowContext(r.Context(), `
		INSERT INTO surat_pengantar(nomor_surat, warga_id, nama, nik, alamat, keperluan, file_url, created_by)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
		strings.TrimSpace(p.NomorSurat), wid, p.Nama, strings.TrimSpace(p.NIK), strings.TrimSpace(p.Alamat),
		strings.TrimSpace(p.Keperluan), fileURL, userFrom(r).ID).Scan(&id)
	if isPgCode(err, "23503") {
		fail(w, http.StatusBadRequest, "wargaId tidak ditemukan")
		return
	}
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	okMsg(w, "Surat Pengantar berhasil dicatat!", map[string]any{"id": id, "fileUrl": fileURL})
}

// ------------------------------------------------------------------- kegiatan

type kegReq struct {
	Tanggal      string `json:"tanggal"`
	NamaKegiatan string `json:"namaKegiatan"`
	Deskripsi    string `json:"deskripsi"`
	FotoURL      string `json:"fotoUrl"`
	FotoBase64   string `json:"fotoBase64"` // opsional: data URL gambar (processBase64Uploads)
}

func (s *Server) kegPrepare(w http.ResponseWriter, p *kegReq) (args []any, ok bool) {
	p.NamaKegiatan = strings.TrimSpace(p.NamaKegiatan)
	if p.NamaKegiatan == "" {
		fail(w, http.StatusBadRequest, "namaKegiatan wajib diisi")
		return nil, false
	}
	d, err := parseDate(p.Tanggal)
	if err != nil {
		fail(w, http.StatusBadRequest, err.Error())
		return nil, false
	}
	var tgl any
	if d.Valid {
		tgl = d.Time
	}
	foto := strings.TrimSpace(p.FotoURL)
	if p.FotoBase64 != "" {
		u, err := s.saveDataURL("kegiatan", p.FotoBase64)
		if err != nil {
			fail(w, http.StatusBadRequest, err.Error())
			return nil, false
		}
		foto = u
	}
	return []any{tgl, p.NamaKegiatan, strings.TrimSpace(p.Deskripsi), foto}, true
}

// GET /api/kegiatan
func (s *Server) kegList(w http.ResponseWriter, r *http.Request) {
	rows, err := s.queryMaps(r.Context(), `
		SELECT id, COALESCE(to_char(tanggal,'YYYY-MM-DD'),'') AS tanggal, nama_kegiatan AS "namaKegiatan",
		       deskripsi, foto_url AS "fotoUrl"
		FROM kegiatan ORDER BY tanggal DESC NULLS LAST, id DESC`)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	writeJSON(w, http.StatusOK, rows)
}

// POST /api/kegiatan
func (s *Server) kegCreate(w http.ResponseWriter, r *http.Request) {
	var p kegReq
	if !decode(w, r, &p, 12<<20) {
		return
	}
	args, ok := s.kegPrepare(w, &p)
	if !ok {
		return
	}
	var id int64
	if err := s.db.QueryRowContext(r.Context(),
		`INSERT INTO kegiatan(tanggal, nama_kegiatan, deskripsi, foto_url) VALUES ($1,$2,$3,$4) RETURNING id`, args...).Scan(&id); err != nil {
		s.serverErr(w, r, err)
		return
	}
	okMsg(w, "Data berhasil ditambahkan!", map[string]any{"id": id, "fotoUrl": args[3]})
}

// PUT /api/kegiatan/{id}
func (s *Server) kegUpdate(w http.ResponseWriter, r *http.Request) {
	id, ok := idParam(w, r, "id")
	if !ok {
		return
	}
	var p kegReq
	if !decode(w, r, &p, 12<<20) {
		return
	}
	args, ok := s.kegPrepare(w, &p)
	if !ok {
		return
	}
	s.execOne(w, r, "Data berhasil diperbarui!",
		`UPDATE kegiatan SET tanggal=$2, nama_kegiatan=$3, deskripsi=$4, foto_url=$5 WHERE id=$1`, append([]any{id}, args...)...)
}

// DELETE /api/kegiatan/{id}
func (s *Server) kegDelete(w http.ResponseWriter, r *http.Request) {
	if id, ok := idParam(w, r, "id"); ok {
		s.execOne(w, r, "Data berhasil dihapus!", `DELETE FROM kegiatan WHERE id=$1`, id)
	}
}

// -------------------------------------------------------------------- notulen

type notReq struct {
	Tanggal     string `json:"tanggal"`
	Judul       string `json:"judul"`
	Isi         string `json:"isi"`
	PertemuanID int64  `json:"pertemuanId"`
}

func notPrepare(w http.ResponseWriter, p *notReq) ([]any, bool) {
	p.Judul = strings.TrimSpace(p.Judul)
	if p.Judul == "" {
		fail(w, http.StatusBadRequest, "judul wajib diisi")
		return nil, false
	}
	d, err := parseDate(p.Tanggal)
	if err != nil {
		fail(w, http.StatusBadRequest, err.Error())
		return nil, false
	}
	var tgl, pid any
	if d.Valid {
		tgl = d.Time
	}
	if p.PertemuanID > 0 {
		pid = p.PertemuanID
	}
	return []any{tgl, p.Judul, p.Isi, pid}, true
}

// GET /api/notulen
func (s *Server) notList(w http.ResponseWriter, r *http.Request) {
	rows, err := s.queryMaps(r.Context(), `
		SELECT id, COALESCE(to_char(tanggal,'YYYY-MM-DD'),'') AS tanggal, judul, isi, pertemuan_id AS "pertemuanId"
		FROM notulen ORDER BY tanggal DESC NULLS LAST, id DESC`)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	writeJSON(w, http.StatusOK, rows)
}

// POST /api/notulen
func (s *Server) notCreate(w http.ResponseWriter, r *http.Request) {
	var p notReq
	if !decode(w, r, &p, 2<<20) {
		return
	}
	args, ok := notPrepare(w, &p)
	if !ok {
		return
	}
	var id int64
	err := s.db.QueryRowContext(r.Context(),
		`INSERT INTO notulen(tanggal, judul, isi, pertemuan_id) VALUES ($1,$2,$3,$4) RETURNING id`, args...).Scan(&id)
	if isPgCode(err, "23503") {
		fail(w, http.StatusBadRequest, "pertemuanId tidak ditemukan")
		return
	}
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	okMsg(w, "Data berhasil ditambahkan!", map[string]any{"id": id})
}

// PUT /api/notulen/{id}
func (s *Server) notUpdate(w http.ResponseWriter, r *http.Request) {
	id, ok := idParam(w, r, "id")
	if !ok {
		return
	}
	var p notReq
	if !decode(w, r, &p, 2<<20) {
		return
	}
	args, ok := notPrepare(w, &p)
	if !ok {
		return
	}
	s.execOne(w, r, "Data berhasil diperbarui!",
		`UPDATE notulen SET tanggal=$2, judul=$3, isi=$4, pertemuan_id=$5 WHERE id=$1`, append([]any{id}, args...)...)
}

// DELETE /api/notulen/{id}
func (s *Server) notDelete(w http.ResponseWriter, r *http.Request) {
	if id, ok := idParam(w, r, "id"); ok {
		s.execOne(w, r, "Data berhasil dihapus!", `DELETE FROM notulen WHERE id=$1`, id)
	}
}

// ------------------------------------------------------------------- pertemuan

type pertReq struct {
	Tanggal    string `json:"tanggal"`
	Judul      string `json:"judul"`
	Lokasi     string `json:"lokasi"`
	Keterangan string `json:"keterangan"`
}

func pertPrepare(w http.ResponseWriter, p *pertReq) ([]any, bool) {
	d, err := parseDate(p.Tanggal)
	if err != nil || !d.Valid {
		fail(w, http.StatusBadRequest, "tanggal wajib diisi (yyyy-MM-dd atau dd/MM/yyyy)")
		return nil, false
	}
	return []any{d.Time, strings.TrimSpace(p.Judul), strings.TrimSpace(p.Lokasi), strings.TrimSpace(p.Keterangan)}, true
}

// GET /api/pertemuan  (sheet UNDANGAN)
func (s *Server) pertList(w http.ResponseWriter, r *http.Request) {
	rows, err := s.queryMaps(r.Context(), `
		SELECT id, to_char(tanggal,'YYYY-MM-DD') AS tanggal, judul, lokasi, keterangan
		FROM pertemuan ORDER BY tanggal DESC, id DESC`)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	writeJSON(w, http.StatusOK, rows)
}

// POST /api/pertemuan
func (s *Server) pertCreate(w http.ResponseWriter, r *http.Request) {
	var p pertReq
	if !decode(w, r, &p, smallBody) {
		return
	}
	args, ok := pertPrepare(w, &p)
	if !ok {
		return
	}
	var id int64
	if err := s.db.QueryRowContext(r.Context(),
		`INSERT INTO pertemuan(tanggal, judul, lokasi, keterangan) VALUES ($1,$2,$3,$4) RETURNING id`, args...).Scan(&id); err != nil {
		s.serverErr(w, r, err)
		return
	}
	okMsg(w, "Data berhasil ditambahkan!", map[string]any{"id": id})
}

// PUT /api/pertemuan/{id}
func (s *Server) pertUpdate(w http.ResponseWriter, r *http.Request) {
	id, ok := idParam(w, r, "id")
	if !ok {
		return
	}
	var p pertReq
	if !decode(w, r, &p, smallBody) {
		return
	}
	args, ok := pertPrepare(w, &p)
	if !ok {
		return
	}
	s.execOne(w, r, "Data berhasil diperbarui!",
		`UPDATE pertemuan SET tanggal=$2, judul=$3, lokasi=$4, keterangan=$5 WHERE id=$1`, append([]any{id}, args...)...)
}

// DELETE /api/pertemuan/{id}
func (s *Server) pertDelete(w http.ResponseWriter, r *http.Request) {
	if id, ok := idParam(w, r, "id"); ok {
		s.execOne(w, r, "Data berhasil dihapus!", `DELETE FROM pertemuan WHERE id=$1`, id)
	}
}
