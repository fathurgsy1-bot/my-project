package api

import (
	"database/sql"
	"errors"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/rt04rw26/backend/internal/arrears"
)

// ----------------------------------------------------------------- pembayaran

type bayarReq struct {
	WargaID int64   `json:"wargaId"`
	Name    string  `json:"name"`
	Month   string  `json:"month"`
	Year    flexInt `json:"year"`
	Amount  flexInt `json:"amount"`
	Note    string  `json:"note"`
}

// POST /api/kas/bayar  (submitKas)
// Dalam SATU transaksi: lunasi tunggakan lama -> isi bulan yang kurang -> catatan
// -> tambah baris pemasukan di kas. Gagal di tengah = tidak ada yang berubah.
func (s *Server) kasBayar(w http.ResponseWriter, r *http.Request) {
	var in bayarReq
	if !decode(w, r, &in, smallBody) {
		return
	}
	amount := int64(in.Amount)
	if amount <= 0 {
		fail(w, http.StatusBadRequest, arrears.ErrAmount.Error())
		return
	}
	if in.WargaID == 0 && strings.TrimSpace(in.Name) == "" {
		fail(w, http.StatusBadRequest, "wargaId atau name wajib diisi")
		return
	}
	ctx := r.Context()
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	defer tx.Rollback()

	// 1. kunci baris warga agar dua pembayaran bersamaan tidak saling menimpa
	var wid int64
	var nama string
	if in.WargaID > 0 {
		err = tx.QueryRowContext(ctx, `SELECT id, nama FROM warga WHERE id=$1 FOR UPDATE`, in.WargaID).Scan(&wid, &nama)
	} else {
		err = tx.QueryRowContext(ctx,
			`SELECT id, nama FROM warga WHERE lower(btrim(nama)) = lower(btrim($1)) FOR UPDATE`, in.Name).Scan(&wid, &nama)
	}
	if errors.Is(err, sql.ErrNoRows) {
		fail(w, http.StatusNotFound, "warga tidak ditemukan")
		return
	}
	if err != nil {
		s.serverErr(w, r, err)
		return
	}

	// 2. data yang dibutuhkan alokasi
	var lama int64
	if err := tx.QueryRowContext(ctx, `SELECT nominal FROM tunggakan_lama WHERE warga_id=$1 FOR UPDATE`, wid).Scan(&lama); err != nil && !errors.Is(err, sql.ErrNoRows) {
		s.serverErr(w, r, err)
		return
	}
	paid := map[[2]int]int64{}
	rows, err := tx.QueryContext(ctx, `SELECT tahun, bulan, bayar FROM angsuran WHERE warga_id=$1`, wid)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	for rows.Next() {
		var t, b int
		var p int64
		if err := rows.Scan(&t, &b, &p); err != nil {
			rows.Close()
			s.serverErr(w, r, err)
			return
		}
		paid[[2]int{t, b}] = p
	}
	rows.Close()

	now := s.now()
	startYear := s.cfg.PaymentStartYear
	if startYear == 0 {
		// sama seperti Sheets: mulai dari blok tahun paling kiri
		if err := tx.QueryRowContext(ctx, `SELECT COALESCE(MIN(tahun), $1) FROM angsuran`, now.Year()).Scan(&startYear); err != nil {
			s.serverErr(w, r, err)
			return
		}
	}
	plan, err := arrears.Allocate(amount, lama, s.cfg.FeePerMonth, startYear,
		func(t, b int) int64 { return paid[[2]int{t, b}] })
	if err != nil {
		fail(w, http.StatusBadRequest, err.Error())
		return
	}

	// 3. tulis perubahan
	if plan.LamaDibayar > 0 {
		if _, err := tx.ExecContext(ctx, `UPDATE tunggakan_lama SET nominal=$2 WHERE warga_id=$1`, wid, plan.LamaBaru); err != nil {
			s.serverErr(w, r, err)
			return
		}
	}
	for _, a := range plan.Alokasi {
		if _, err := tx.ExecContext(ctx, `
			INSERT INTO angsuran(warga_id, tahun, bulan, bayar) VALUES ($1,$2,$3,$4)
			ON CONFLICT (warga_id, tahun, bulan) DO UPDATE SET bayar = angsuran.bayar + EXCLUDED.bayar`,
			wid, a.Tahun, a.Bulan, a.Tambah); err != nil {
			s.serverErr(w, r, err)
			return
		}
	}
	if note := strings.TrimSpace(in.Note); note != "" {
		if bln := monthIndex(in.Month); bln > 0 && in.Year >= 2000 && in.Year <= 2100 {
			if _, err := tx.ExecContext(ctx, `
				INSERT INTO angsuran(warga_id, tahun, bulan, bayar, catatan) VALUES ($1,$2,$3,0,$4)
				ON CONFLICT (warga_id, tahun, bulan) DO UPDATE SET catatan =
				  CASE WHEN angsuran.catatan = '' THEN EXCLUDED.catatan
				       ELSE angsuran.catatan || E'\n---\nTambahan: ' || EXCLUDED.catatan END`,
				wid, int(in.Year), bln, note); err != nil {
				s.serverErr(w, r, err)
				return
			}
		}
	}
	var kasID int64
	if err := tx.QueryRowContext(ctx, `
		INSERT INTO kas(tanggal, keterangan, bulan, tahun, debet, kredit, warga_id, created_by)
		VALUES (now(), $1, $2, $3, $4, 0, $5, $6) RETURNING id`,
		"Pembayaran Kas An. "+nama, int(now.Month()), now.Year(), amount, wid, userFrom(r).ID).Scan(&kasID); err != nil {
		s.serverErr(w, r, err)
		return
	}
	if err := tx.Commit(); err != nil {
		s.serverErr(w, r, err)
		return
	}
	okMsg(w, "Pembayaran berhasil diproses, sisa otomatis menutupi kekosongan, dan data masuk ke kas!",
		map[string]any{"kasId": kasID, "nama": nama, "rincian": plan})
}

// ------------------------------------------------------------------ CRUD kas

type kasReq struct {
	Keterangan string  `json:"keterangan"`
	Tanggal    string  `json:"tanggal"` // opsional, default sekarang
	Bulan      string  `json:"bulan"`   // opsional, nama/angka; default dari tanggal
	Debet      flexInt `json:"debet"`
	Kredit     flexInt `json:"kredit"`
}

func (s *Server) parseKas(w http.ResponseWriter, r *http.Request) (*kasReq, time.Time, int, bool) {
	var in kasReq
	if !decode(w, r, &in, smallBody) {
		return nil, time.Time{}, 0, false
	}
	in.Keterangan = strings.TrimSpace(in.Keterangan)
	if in.Keterangan == "" {
		fail(w, http.StatusBadRequest, "keterangan wajib diisi")
		return nil, time.Time{}, 0, false
	}
	if in.Debet < 0 || in.Kredit < 0 || (in.Debet == 0 && in.Kredit == 0) {
		fail(w, http.StatusBadRequest, "isi pemasukan (debet) atau pengeluaran (kredit) dengan angka > 0")
		return nil, time.Time{}, 0, false
	}
	tgl := s.now()
	if strings.TrimSpace(in.Tanggal) != "" {
		d, err := parseDate(in.Tanggal)
		if err != nil {
			fail(w, http.StatusBadRequest, err.Error())
			return nil, time.Time{}, 0, false
		}
		tgl = time.Date(d.Time.Year(), d.Time.Month(), d.Time.Day(), tgl.Hour(), tgl.Minute(), tgl.Second(), 0, s.cfg.Location)
	}
	bln := int(tgl.Month())
	if strings.TrimSpace(in.Bulan) != "" {
		if bln = monthIndex(in.Bulan); bln == 0 {
			fail(w, http.StatusBadRequest, "bulan tidak valid")
			return nil, time.Time{}, 0, false
		}
	}
	return &in, tgl, bln, true
}

// GET /api/kas?tahun=&bulan=   (saldo berjalan dihitung otomatis oleh view)
func (s *Server) kasList(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	tahun, _ := strconv.Atoi(q.Get("tahun"))
	bulan := monthIndex(q.Get("bulan"))
	rows, err := s.queryMaps(r.Context(), `
		SELECT id, no, tanggal, keterangan, bulan, tahun, debet, kredit, saldo, warga_id AS "wargaId"
		FROM v_kas_saldo
		WHERE ($1 = 0 OR tahun = $1) AND ($2 = 0 OR bulan = $2)
		ORDER BY tanggal, id`, tahun, bulan)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	var masuk, keluar, saldo int64
	if err := s.db.QueryRowContext(r.Context(),
		`SELECT COALESCE(SUM(debet),0), COALESCE(SUM(kredit),0) FROM kas`).Scan(&masuk, &keluar); err != nil {
		s.serverErr(w, r, err)
		return
	}
	saldo = masuk - keluar
	writeJSON(w, http.StatusOK, map[string]any{"rows": rows, "totalMasuk": masuk, "totalKeluar": keluar, "saldo": saldo})
}

// POST /api/kas
func (s *Server) kasCreate(w http.ResponseWriter, r *http.Request) {
	in, tgl, bln, ok := s.parseKas(w, r)
	if !ok {
		return
	}
	var id int64
	err := s.db.QueryRowContext(r.Context(), `
		INSERT INTO kas(tanggal, keterangan, bulan, tahun, debet, kredit, created_by)
		VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
		tgl, in.Keterangan, bln, tgl.Year(), int64(in.Debet), int64(in.Kredit), userFrom(r).ID).Scan(&id)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	okMsg(w, "Data berhasil ditambahkan!", map[string]any{"id": id})
}

// PUT /api/kas/{id}
func (s *Server) kasUpdate(w http.ResponseWriter, r *http.Request) {
	id, ok := idParam(w, r, "id")
	if !ok {
		return
	}
	in, tgl, bln, ok := s.parseKas(w, r)
	if !ok {
		return
	}
	res, err := s.db.ExecContext(r.Context(), `
		UPDATE kas SET tanggal=$2, keterangan=$3, bulan=$4, tahun=$5, debet=$6, kredit=$7 WHERE id=$1`,
		id, tgl, in.Keterangan, bln, tgl.Year(), int64(in.Debet), int64(in.Kredit))
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	if n, _ := res.RowsAffected(); n == 0 {
		fail(w, http.StatusNotFound, "data tidak ditemukan")
		return
	}
	okMsg(w, "Data berhasil diperbarui!", nil)
}

// DELETE /api/kas/{id}
func (s *Server) kasDelete(w http.ResponseWriter, r *http.Request) {
	id, ok := idParam(w, r, "id")
	if !ok {
		return
	}
	res, err := s.db.ExecContext(r.Context(), `DELETE FROM kas WHERE id=$1`, id)
	if err != nil {
		s.serverErr(w, r, err)
		return
	}
	if n, _ := res.RowsAffected(); n == 0 {
		fail(w, http.StatusNotFound, "data tidak ditemukan")
		return
	}
	okMsg(w, "Data berhasil dihapus!", nil)
}
