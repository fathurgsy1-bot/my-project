package api

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"net/http"
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/lib/pq"
	"github.com/rt04rw26/backend/internal/arrears"
)

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}

func fail(w http.ResponseWriter, status int, msg string) {
	writeJSON(w, status, map[string]any{"success": false, "error": msg, "message": msg})
}

func okMsg(w http.ResponseWriter, msg string, extra map[string]any) {
	out := map[string]any{"success": true, "message": msg}
	for k, v := range extra {
		out[k] = v
	}
	writeJSON(w, http.StatusOK, out)
}

// serverErr mencatat error asli di log, tetapi tidak membocorkannya ke klien.
func (s *Server) serverErr(w http.ResponseWriter, r *http.Request, err error) {
	s.log.Error("request gagal", "method", r.Method, "path", r.URL.Path, "err", err)
	fail(w, http.StatusInternalServerError, "terjadi kesalahan pada server")
}

func decode(w http.ResponseWriter, r *http.Request, dst any, maxBytes int64) bool {
	r.Body = http.MaxBytesReader(w, r.Body, maxBytes)
	if err := json.NewDecoder(r.Body).Decode(dst); err != nil {
		fail(w, http.StatusBadRequest, "body JSON tidak valid atau terlalu besar")
		return false
	}
	return true
}

const smallBody = 1 << 20 // 1 MiB

func idParam(w http.ResponseWriter, r *http.Request, name string) (int64, bool) {
	id, err := strconv.ParseInt(r.PathValue(name), 10, 64)
	if err != nil || id <= 0 {
		fail(w, http.StatusBadRequest, "parameter "+name+" tidak valid")
		return 0, false
	}
	return id, true
}

func isPgCode(err error, code string) bool {
	var pe *pq.Error
	return errors.As(err, &pe) && string(pe.Code) == code
}
func isUnique(err error) bool { return isPgCode(err, "23505") }

func (s *Server) now() time.Time { return time.Now().In(s.cfg.Location) }

// flexInt menerima angka JSON, atau string seperti "35.000" / "Rp 35000".
type flexInt int64

func (f *flexInt) UnmarshalJSON(b []byte) error {
	str := strings.TrimSpace(string(b))
	if str == "null" || str == `""` {
		*f = 0
		return nil
	}
	if strings.HasPrefix(str, `"`) {
		digits := regexp.MustCompile(`[^0-9-]`).ReplaceAllString(str, "")
		n, err := strconv.ParseInt(digits, 10, 64)
		if err != nil {
			return errors.New("angka tidak valid")
		}
		*f = flexInt(n)
		return nil
	}
	var fl float64
	if err := json.Unmarshal(b, &fl); err != nil {
		return errors.New("angka tidak valid")
	}
	*f = flexInt(fl)
	return nil
}

var dateLayouts = []string{"2006-01-02", "02/01/2006", "2/1/2006", "02-01-2006", "2-1-2006",
	"02/01/2006 15:04:05", time.RFC3339}

// parseDate menerima yyyy-MM-dd, dd/MM/yyyy, dd-MM-yyyy (+ jam). Kosong = NULL.
func parseDate(s string) (sql.NullTime, error) {
	s = strings.TrimSpace(s)
	if s == "" {
		return sql.NullTime{}, nil
	}
	for _, l := range dateLayouts {
		if t, err := time.Parse(l, s); err == nil {
			return sql.NullTime{Time: t, Valid: true}, nil
		}
	}
	return sql.NullTime{}, errors.New("format tanggal tidak dikenali: " + s)
}

// monthIndex mengubah "Mei"/"mei"/"5" menjadi 5. 0 = tidak valid.
func monthIndex(s string) int {
	s = strings.TrimSpace(s)
	if n, err := strconv.Atoi(s); err == nil && n >= 1 && n <= 12 {
		return n
	}
	for i, b := range arrears.BulanList {
		if strings.EqualFold(b, s) {
			return i + 1
		}
	}
	return 0
}

func nullStr(s string) any {
	if s = strings.TrimSpace(s); s == "" {
		return nil
	}
	return s
}

// queryMaps menjalankan query dan mengubah baris menjadi []map (alias kolom = nama field JSON).
func (s *Server) queryMaps(ctx context.Context, query string, args ...any) ([]map[string]any, error) {
	rows, err := s.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	cols, err := rows.Columns()
	if err != nil {
		return nil, err
	}
	out := []map[string]any{}
	for rows.Next() {
		vals := make([]any, len(cols))
		ptrs := make([]any, len(cols))
		for i := range vals {
			ptrs[i] = &vals[i]
		}
		if err := rows.Scan(ptrs...); err != nil {
			return nil, err
		}
		m := make(map[string]any, len(cols))
		for i, c := range cols {
			if b, ok := vals[i].([]byte); ok {
				m[c] = string(b)
			} else {
				m[c] = vals[i]
			}
		}
		out = append(out, m)
	}
	return out, rows.Err()
}
