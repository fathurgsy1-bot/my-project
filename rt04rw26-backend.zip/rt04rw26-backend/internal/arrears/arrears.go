// Package arrears berisi logika bisnis murni (tanpa DB) hasil port dari Apps Script:
//   - Compute   : getRekapTunggakan (rincian tunggakan per warga)
//   - Allocate  : submitKas (alokasi setoran ke tunggakan lama lalu ke bulan-bulan berikutnya)
package arrears

import (
	"errors"
	"sort"
	"strings"
)

// BulanList nama bulan (indeks 0 = Januari), sama seperti di Apps Script.
var BulanList = []string{"Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli",
	"Agustus", "September", "Oktober", "November", "Desember"}

const StatusLunas = "Lunas & Aman"

type MonthPay struct {
	Bayar   int64
	Catatan string
}

type Detail struct {
	Label   string `json:"label"`
	Catatan string `json:"catatan"`
	Info    bool   `json:"info,omitempty"` // true = hanya catatan pada bulan yang sudah lunas
}

type Row struct {
	WargaID       int64    `json:"wargaId"`
	No            int      `json:"no"`
	Nama          string   `json:"nama"`
	TunggakanLama int64    `json:"tunggakanLama"`
	Total         int64    `json:"total"`
	Status        string   `json:"status"`
	Rincian       []Detail `json:"rincian"`
	Catatan       string   `json:"catatan"`
}

// Input data satu warga untuk tahun berjalan.
type Input struct {
	WargaID     int64
	Nama        string
	Lama        int64
	CatatanLama string
	Bulan       map[int]MonthPay // kunci 1..12
}

// Compute menghitung tunggakan satu warga. batasBulan = jumlah bulan yang ikut
// dihitung (bulan 1..batasBulan). Bulan yang belum dibayar penuh menjadi defisit.
func Compute(in Input, batasBulan int, fee int64) Row {
	if batasBulan > 12 {
		batasBulan = 12
	}
	var totalDefisit int64
	var unpaidLabels []string
	var rincian []Detail

	for m := 0; m < batasBulan; m++ {
		e := in.Bulan[m+1]
		nama := BulanList[m]
		if e.Bayar < fee {
			totalDefisit += fee - e.Bayar
			label := nama
			if e.Bayar > 0 {
				label = nama + " (Kurang)"
			}
			unpaidLabels = append(unpaidLabels, label)
			rincian = append(rincian, Detail{Label: label, Catatan: e.Catatan})
		} else if e.Catatan != "" {
			rincian = append(rincian, Detail{Label: nama + " (Lunas)", Catatan: e.Catatan, Info: true})
		}
	}

	total := in.Lama + totalDefisit
	var labels []string
	if in.Lama > 0 {
		labels = append(labels, "Tunggakan Lama")
		rincian = append([]Detail{{Label: "Tunggakan Lama", Catatan: in.CatatanLama}}, rincian...)
	}
	labels = append(labels, unpaidLabels...)

	status := StatusLunas
	if total > 0 {
		status = strings.Join(labels, ", ")
	}

	var gabung []string
	if in.CatatanLama != "" {
		gabung = append(gabung, in.CatatanLama)
	}
	for _, r := range rincian {
		if r.Catatan != "" && r.Label != "Tunggakan Lama" {
			gabung = append(gabung, "["+r.Label+"]: "+r.Catatan)
		}
	}
	if rincian == nil {
		rincian = []Detail{}
	}
	return Row{
		WargaID: in.WargaID, Nama: in.Nama, TunggakanLama: in.Lama, Total: total,
		Status: status, Rincian: rincian, Catatan: strings.Join(gabung, " | "),
	}
}

// ComputeAll menghitung semua warga, mengurutkan dari tunggakan terbesar dan memberi nomor.
func ComputeAll(inputs []Input, batasBulan int, fee int64) []Row {
	rows := make([]Row, 0, len(inputs))
	for _, in := range inputs {
		rows = append(rows, Compute(in, batasBulan, fee))
	}
	sort.SliceStable(rows, func(i, j int) bool { return rows[i].Total > rows[j].Total })
	for i := range rows {
		rows[i].No = i + 1
	}
	return rows
}

// ---------------------------------------------------------------- alokasi bayar

type Allocation struct {
	Tahun  int   `json:"tahun"`
	Bulan  int   `json:"bulan"`
	Tambah int64 `json:"tambah"`
}

type PaymentPlan struct {
	LamaDibayar int64        `json:"tunggakanLamaDibayar"`
	LamaBaru    int64        `json:"tunggakanLamaBaru"`
	Alokasi     []Allocation `json:"alokasi"`
}

var (
	ErrAmount   = errors.New("nominal harus lebih dari 0")
	ErrTooLarge = errors.New("nominal terlalu besar: melebihi 20 tahun ke depan")
)

const maxYearsAhead = 20

// Allocate mengikuti submitKas di Apps Script:
//  1. setoran dipakai dulu untuk melunasi tunggakan lama,
//  2. sisanya mengisi bulan yang kurang dari `fee`, berurutan mulai startYear/Januari,
//     lalu lanjut ke tahun berikutnya bila perlu.
//
// paid(tahun, bulan) mengembalikan nominal yang sudah dibayar di bulan itu.
func Allocate(amount, lama, fee int64, startYear int, paid func(tahun, bulan int) int64) (PaymentPlan, error) {
	if amount <= 0 {
		return PaymentPlan{}, ErrAmount
	}
	plan := PaymentPlan{LamaBaru: lama}
	sisa := amount

	if lama > 0 {
		if sisa >= lama {
			plan.LamaDibayar, plan.LamaBaru, sisa = lama, 0, sisa-lama
		} else {
			plan.LamaDibayar, plan.LamaBaru, sisa = sisa, lama-sisa, 0
		}
	}
	for y := startYear; sisa > 0 && y <= startYear+maxYearsAhead; y++ {
		for m := 1; m <= 12 && sisa > 0; m++ {
			sudah := paid(y, m)
			if sudah >= fee {
				continue
			}
			bayar := fee - sudah
			if sisa < bayar {
				bayar = sisa
			}
			plan.Alokasi = append(plan.Alokasi, Allocation{Tahun: y, Bulan: m, Tambah: bayar})
			sisa -= bayar
		}
	}
	if sisa > 0 {
		return PaymentPlan{}, ErrTooLarge
	}
	return plan, nil
}
