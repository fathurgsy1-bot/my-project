package arrears

import "testing"

const fee = 35000

func TestComputeLunas(t *testing.T) {
	bulan := map[int]MonthPay{1: {Bayar: fee}, 2: {Bayar: fee}, 3: {Bayar: 40000, Catatan: "titip"}}
	r := Compute(Input{Nama: "Budi", Bulan: bulan}, 3, fee)
	if r.Total != 0 || r.Status != StatusLunas {
		t.Fatalf("harus lunas, dapat total=%d status=%q", r.Total, r.Status)
	}
	if len(r.Rincian) != 1 || !r.Rincian[0].Info || r.Rincian[0].Label != "Maret (Lunas)" {
		t.Fatalf("rincian info salah: %+v", r.Rincian)
	}
	if r.Catatan != "[Maret (Lunas)]: titip" {
		t.Fatalf("catatan gabungan salah: %q", r.Catatan)
	}
}

func TestComputeTunggakan(t *testing.T) {
	bulan := map[int]MonthPay{1: {Bayar: fee}, 2: {Bayar: 10000, Catatan: "kurang"}}
	r := Compute(Input{Nama: "Sari", Lama: 70000, CatatanLama: "2025", Bulan: bulan}, 4, fee)
	// Feb kurang 25.000 + Mar 35.000 + Apr 35.000 + lama 70.000
	if want := int64(70000 + 25000 + 35000 + 35000); r.Total != want {
		t.Fatalf("total=%d want=%d", r.Total, want)
	}
	if r.Status != "Tunggakan Lama, Februari (Kurang), Maret, April" {
		t.Fatalf("status=%q", r.Status)
	}
	if r.Rincian[0].Label != "Tunggakan Lama" {
		t.Fatalf("tunggakan lama harus di urutan pertama: %+v", r.Rincian)
	}
	if r.Catatan != "2025 | [Februari (Kurang)]: kurang" {
		t.Fatalf("catatan=%q", r.Catatan)
	}
}

func TestComputeAllUrutDanNomor(t *testing.T) {
	rows := ComputeAll([]Input{
		{Nama: "A", Lama: 0}, {Nama: "B", Lama: 100000}, {Nama: "C", Lama: 50000},
	}, 0, fee)
	if rows[0].Nama != "B" || rows[1].Nama != "C" || rows[2].Nama != "A" {
		t.Fatalf("urutan salah: %v %v %v", rows[0].Nama, rows[1].Nama, rows[2].Nama)
	}
	if rows[0].No != 1 || rows[2].No != 3 {
		t.Fatal("nomor urut salah")
	}
}

func TestAllocate(t *testing.T) {
	sudah := map[[2]int]int64{{2026, 1}: fee, {2026, 2}: 20000}
	paid := func(y, m int) int64 { return sudah[[2]int{y, m}] }

	// 100.000: lunasi lama 30.000, lalu 70.000 -> Feb kurang 15.000, Mar 35.000, Apr 20.000
	p, err := Allocate(100000, 30000, fee, 2026, paid)
	if err != nil {
		t.Fatal(err)
	}
	if p.LamaDibayar != 30000 || p.LamaBaru != 0 {
		t.Fatalf("lama: %+v", p)
	}
	want := []Allocation{{2026, 2, 15000}, {2026, 3, 35000}, {2026, 4, 20000}}
	if len(p.Alokasi) != len(want) {
		t.Fatalf("alokasi=%+v", p.Alokasi)
	}
	for i := range want {
		if p.Alokasi[i] != want[i] {
			t.Fatalf("alokasi[%d]=%+v want %+v", i, p.Alokasi[i], want[i])
		}
	}

	// setoran lebih kecil dari tunggakan lama: hanya mengurangi lama
	p, _ = Allocate(10000, 30000, fee, 2026, paid)
	if p.LamaBaru != 20000 || len(p.Alokasi) != 0 {
		t.Fatalf("parsial: %+v", p)
	}
}

func TestAllocateLintasTahun(t *testing.T) {
	paid := func(y, m int) int64 {
		if y == 2026 {
			return fee
		}
		return 0
	}
	p, err := Allocate(fee*2, 0, fee, 2026, paid)
	if err != nil {
		t.Fatal(err)
	}
	if p.Alokasi[0].Tahun != 2027 || p.Alokasi[0].Bulan != 1 || len(p.Alokasi) != 2 {
		t.Fatalf("harus lanjut ke 2027: %+v", p.Alokasi)
	}
}

func TestAllocateError(t *testing.T) {
	if _, err := Allocate(0, 0, fee, 2026, func(int, int) int64 { return 0 }); err != ErrAmount {
		t.Fatalf("want ErrAmount, got %v", err)
	}
	if _, err := Allocate(fee*12*30, 0, fee, 2026, func(int, int) int64 { return 0 }); err != ErrTooLarge {
		t.Fatalf("want ErrTooLarge, got %v", err)
	}
}
