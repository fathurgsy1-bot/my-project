// Package config membaca konfigurasi dari environment variable.
package config

import (
	"errors"
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"
)

type Config struct {
	Port             string
	DatabaseURL      string
	JWTSecret        string
	TokenTTL         time.Duration
	PublicBaseURL    string // dipakai di isi QR, mis. https://rt04rw26.example.com
	StorageDir       string // folder upload & QR (pengganti Google Drive)
	FeePerMonth      int64  // BIAYA_PER_BULAN / ANGSURAN_BULANAN (default 35000)
	PaymentStartYear int    // 0 = otomatis (tahun terkecil di tabel angsuran)
	Location         *time.Location
	CORSOrigins      []string
	TrustProxy       bool
	AutoMigrate      bool
	AdminUser        string
	AdminPass        string
	Wilayah          string // label di halaman cek tunggakan
}

func Load() (*Config, error) {
	c := &Config{
		Port:          get("PORT", "8080"),
		DatabaseURL:   os.Getenv("DATABASE_URL"),
		JWTSecret:     os.Getenv("JWT_SECRET"),
		PublicBaseURL: strings.TrimRight(get("PUBLIC_BASE_URL", "http://localhost:8080"), "/"),
		StorageDir:    get("STORAGE_DIR", "./data"),
		AdminUser:     os.Getenv("ADMIN_USERNAME"),
		AdminPass:     os.Getenv("ADMIN_PASSWORD"),
		Wilayah:       get("WILAYAH_LABEL", "RT 04 / RW 026 - Kel. Meteseh"),
		TrustProxy:    getBool("TRUST_PROXY", false),
		AutoMigrate:   getBool("AUTO_MIGRATE", true),
	}
	var err error
	if c.FeePerMonth, err = strconv.ParseInt(get("FEE_PER_MONTH", "35000"), 10, 64); err != nil || c.FeePerMonth <= 0 {
		return nil, errors.New("FEE_PER_MONTH harus angka > 0")
	}
	if c.PaymentStartYear, err = strconv.Atoi(get("PAYMENT_START_YEAR", "0")); err != nil {
		return nil, errors.New("PAYMENT_START_YEAR harus angka")
	}
	ttl, err := strconv.Atoi(get("TOKEN_TTL_HOURS", "12"))
	if err != nil || ttl <= 0 {
		return nil, errors.New("TOKEN_TTL_HOURS harus angka > 0")
	}
	c.TokenTTL = time.Duration(ttl) * time.Hour
	if c.Location, err = time.LoadLocation(get("TZ_NAME", "Asia/Jakarta")); err != nil {
		return nil, fmt.Errorf("TZ_NAME tidak valid: %w", err)
	}
	for _, o := range strings.Split(os.Getenv("CORS_ORIGINS"), ",") {
		if o = strings.TrimSpace(o); o != "" {
			c.CORSOrigins = append(c.CORSOrigins, o)
		}
	}
	if c.DatabaseURL == "" {
		return nil, errors.New("DATABASE_URL wajib diisi")
	}
	if len(c.JWTSecret) < 32 {
		return nil, errors.New("JWT_SECRET wajib diisi, minimal 32 karakter (mis. `openssl rand -hex 32`)")
	}
	return c, nil
}

func get(k, def string) string {
	if v := strings.TrimSpace(os.Getenv(k)); v != "" {
		return v
	}
	return def
}

func getBool(k string, def bool) bool {
	v, err := strconv.ParseBool(strings.TrimSpace(os.Getenv(k)))
	if err != nil {
		return def
	}
	return v
}
